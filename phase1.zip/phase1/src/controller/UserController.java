package controller;

import models.DataBase.DataBase;
import models.GoodsModels.Good;
import models.Logs.ShoppingLog;
import models.Requests.Request;
import models.Requests.RequestStatus;
import models.UsersModels.*;

import java.util.ArrayList;
import java.util.HashMap;

public class UserController {
    public static DataBase dataBase=DataBase.getDataBase();

    private static GoodController goodController = GoodController.getGoodController();

    private static UserController userController=new UserController();

    public static UserController getUserController() {
        return userController;
    }
    public  void addCustomer(String userName,String firstName,String lastName,String emailAddress,String telephoneNumber,String password){
        Customer customer=new Customer(userName,firstName,lastName,emailAddress,telephoneNumber,password, AccountType.CUSTOMER);
        dataBase.getCustomers().put(userName,customer);
    }
    public  boolean isThisUsernameUsed(String userName) throws Exception{
        int counter=0;
        for (String userNames : dataBase.getCustomers().keySet()) {
            if(userNames.equalsIgnoreCase(userName))
                counter++;
        }
        for (String userNames : dataBase.getSellers().keySet()) {
            if(userNames.equalsIgnoreCase(userName))
                counter++;
        }
        for (String userNames : dataBase.getManagers().keySet()) {
            if(userNames.equalsIgnoreCase(userName))
                counter++;
        }

        if(counter!=0){
            throw new Exception("This user name has been used before.");
        }else{
            return true;
        }

    }

    public  boolean confirmPassword(String password,String repeatedPassword){
        if((password.trim()).equalsIgnoreCase(repeatedPassword.trim())){
            return true;
        }else{
            return false;
        }
    }


    public  void acceptRequest(Request request){
        request.setRequestStatus(RequestStatus.ACCEPTED);
    }
    public  void rejectRequest(Request request){
        request.setRequestStatus(RequestStatus.REJECTED);
    }

    public Account findAccountByUserName(String userName)throws Exception{
        for (String userNames : dataBase.getCustomers().keySet()) {
            if(userName.equals(userNames))
                return dataBase.getCustomers().get(userName);
        }
        for (String userNames : dataBase.getManagers().keySet()) {
            if(userName.equals(userNames))
                return dataBase.getManagers().get(userName);
        }
        for (String userNames : dataBase.getSellers().keySet()) {
            if(userName.equals(userNames))
                return dataBase.getSellers().get(userName);
        }
        throw new Exception("User name or Password is incorrect");
    }
    public boolean checkPassword(Account account,String password)throws Exception{
        if(account.getPassword().equals(password)){
            return true;
        }else{
            throw new Exception("User name or Password is incorrect.");
        }
    }
    public boolean loginProcess(String userName, String password) throws Exception {
        boolean isThisUserNameCorrect;
        boolean isPasswordCorrect;
        Account account = null;
        account=findAccountByUserName(userName);
        isPasswordCorrect=checkPassword(account,password);
        if(account!=null &&  isPasswordCorrect==true){
            return true;
        }else{
            return false;
        }
    }
    public Account findLoginAccount(){
            for (Seller seller : dataBase.getSellers().values()) {
                if (seller.isLogin()) {
                    return seller;
                }
            }
            for (Customer customer : dataBase.getCustomers().values()) {
                if (customer.isLogin()) {
                    return customer;
                }
            }
            for (Manager manager : dataBase.getManagers().values()) {
                if (manager.isLogin()) {
                    return manager;
                }
            }
            return null;
    }
    public void logOff(Account account){
        account.setLogin(false);
    }

    public void login(Account account){
        account.setLogin(true);
    }

    public Seller findSellerFromAccount(Account account) {
        if (account.getAccountType().equals(AccountType.SELLER)) {
            for (String userName : dataBase.getSellers().keySet()) {
                if (userName.equals(account.getUserName()))
                    return dataBase.getSellers().get(userName);
            }
        }
        return null;
    }
    public void changeFirstName(Account account,String firstName){
        account.setFirstName(firstName);
    }
    public void changeLastName(Account account,String lastName){
        account.setLastName(lastName);
    }
    public void changeEmailAddress(Account account,String emailAddress){
        account.setEmailAddress(emailAddress);
    }public void changeTelephoneNumber(Account account,String telephoneNumber){
        account.setTelephoneNumber(telephoneNumber);
    }
    public void changePassword(Account account,String password,String confirmPassword){
        if(confirmPassword(password,confirmPassword)){
            account.setPassword(password);
        }
    }
    public void changeCompanyForSeller(Seller seller,String companyName){
        seller.setCompanyName(companyName);
    }


    public void addCreditForCustomer (Customer customer,double creditToAdd){
        double currentCredit = customer.getCredit();
        customer.setCredit(currentCredit+creditToAdd);
    }
    public HashMap<Good,Integer> getShoppingItemsForShoppingCart(Customer customer){
        return customer.getShoppingCart().getGoodInCart();
    }
    public HashMap<Integer,Good> getShoppingCartWithID(Customer customer){
        HashMap<Integer,Good> shoppingCartWithID = new HashMap<>();
        HashMap<Good,Integer> cartItems = userController.getShoppingItemsForShoppingCart(customer);
        int i=2;
        for (Good good : cartItems.keySet()) {
            shoppingCartWithID.put(i,good);
            i++;
        }
        return shoppingCartWithID;
    }
    public void addItemToCart(Customer customer,Good good,int number) throws Exception{
        if(good.getNumbersOfGoodsInStore() > number){
            customer.getShoppingCart().getGoodInCart().put(good,number);
        }else{
            throw new Exception("There is only " + good.getNumbersOfGoodsInStore() + "item of " + good.getName() + "in the store");
        }

    }
    public void removeItemFromCart(Customer customer , Good good ,int number ) throws Exception{
       int goodAmountInShoppingCart =  customer.getShoppingCart().getGoodInCart().get(good);
       if(goodAmountInShoppingCart - number > 0 ){
           int newGoodAmountInShoppingCart = goodAmountInShoppingCart - number;
           customer.getShoppingCart().getGoodInCart().replace(good,goodAmountInShoppingCart , newGoodAmountInShoppingCart);
       }else if(goodAmountInShoppingCart - number ==0){
           customer.getShoppingCart().getGoodInCart().remove(good);
       }else if(goodAmountInShoppingCart - number <0){
           throw  new Exception("Invalid number");
       }
    }
    public ArrayList<ShoppingLog> getShoppingHistoryForCustomer(Customer customer){
        ArrayList<ShoppingLog> shoppingHistory = new ArrayList<>();
        for (ShoppingLog shoppingLog : dataBase.getShoppingLogs().values()) {
            if(shoppingLog.getCustomer().equals(customer))
                shoppingHistory.add(shoppingLog);
        }
        return shoppingHistory;
    }
    public Seller findSellerWithUserName(String  sellerUserName) throws Exception {
        if(dataBase.getSellers().containsKey(sellerUserName)){
            return dataBase.getSellers().get(sellerUserName);
        }else{
            throw new Exception("Seller didn't found");
        }
    }
    public boolean findSeller(Seller seller) throws Exception {
        if(dataBase.getSellers().containsValue(seller)){
            return true;
        }else{
            throw new Exception("Seller didn't find.") ;
        }
    }
    public void updateSeller(Seller seller) throws Exception {
        if(findSeller(seller)){
            dataBase.getSellers().replace(seller.getUserName(),seller);
        }
    }
    public  void addManager(String userName,String firstName,String lastName,String emailAddress,String telephoneNumber,String password){
        Manager manager = new Manager(userName, firstName, lastName, emailAddress, telephoneNumber, password, AccountType.MANAGER);
        dataBase.getManagers().put(userName, manager);

    }
    public HashMap<Integer,Customer> getAllCustomersWithId(){
        HashMap<Integer,Customer> allCustomersWithId = new HashMap<>();
        int i=2;
        for (Customer customer : dataBase.getCustomers().values()) {
            allCustomersWithId.put(i,customer);
            i++;
        }
        return allCustomersWithId;
    }
    public HashMap<Integer,Seller> getAllSellersWithId(){
        HashMap<Integer,Seller> allSellersWithId = new HashMap<>();
        int i=2;
        for (Seller seller : dataBase.getSellers().values()) {
            allSellersWithId.put(i,seller);
            i++;
        }
        return allSellersWithId;
    }
    public void changeCustomerAccountToSeller(Customer customer,String companyName){
        String userName = customer.getUserName();
        String firstName = customer.getFirstName();
        String lastName = customer.getLastName();
        String emailAddress = customer.getEmailAddress();
        String telephoneNumber = customer.getTelephoneNumber();
        String password = customer.getPassword();
        Seller seller = new Seller(userName,firstName,lastName,emailAddress,telephoneNumber,password,AccountType.SELLER,companyName);
        dataBase.getSellers().put(seller.getUserName(),seller);
        dataBase.getCustomers().remove(customer.getUserName(),customer);
    }
    public void removeCustomer(Customer customer){
        dataBase.getCustomers().remove(customer.getUserName(),customer);
    }
    public void changeCustomerAccountToManager(Customer customer){
        String userName = customer.getUserName();
        String firstName = customer.getFirstName();
        String lastName = customer.getLastName();
        String emailAddress = customer.getEmailAddress();
        String telephoneNumber = customer.getTelephoneNumber();
        String password = customer.getPassword();
        Manager manager = new Manager(userName,firstName,lastName,emailAddress,telephoneNumber,password,AccountType.MANAGER);
        dataBase.getManagers().put(manager.getUserName(),manager);
        dataBase.getCustomers().remove(customer.getUserName(),customer);
    }






}
