package controller;

import models.DataBase.DataBase;
import models.GoodsModels.Good;
import models.Requests.Request;
import models.Requests.RequestStatus;
import models.Requests.RequestType;
import models.Sales.Sale;
import models.Sales.SaleStatus;
import models.UsersModels.Seller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

public class SaleController {
    private DataBase dataBase = DataBase.getDataBase();
    private GoodController goodController = GoodController.getGoodController();
    private UserController userController = UserController.getUserController();

    private static SaleController saleController  = new SaleController();

    public static SaleController getSaleController() {
        return saleController;
    }

    public ArrayList<Sale> getAllSale() throws Exception{
        if(dataBase.getSales() == null){
            throw new Exception("There is no sale yet!");
        }
        return  dataBase.getSales();
    }

    public HashMap<Integer, Good> getGoodsWithSaleById() throws Exception {
        int i=2;
        ArrayList<Sale> sales = getAllSale();
        HashMap<Integer,Good> goodsWithSaleById = new HashMap<>();
        for (Sale sale : sales) {
            ArrayList<Good> goodsInThisSale = sale.getGoods();
            for (Good good : goodsInThisSale) {
                goodsWithSaleById.put(i,good);
                i++;
            }
        }
        return goodsWithSaleById;
    }
    public Sale getSaleByGood(Good good)  {
     ArrayList<Sale> allSales = dataBase.getSales();
        for (Sale sale : allSales) {
            if(sale.getGoods().contains(good))
                return sale;
        }
        return null;

    }
    public void addSale(Sale sale){
        dataBase.getSales().add(sale);
    }

    public ArrayList<Sale> getActiveSales(){
        ArrayList<Sale> activeSales = new ArrayList<>();
        for (Sale sale : dataBase.getSales()) {
            if(sale.getSaleStatus().equals(SaleStatus.CONFIRMED)){
                activeSales.add(sale);
            }
        }
        return activeSales;
    }
    public void addRequestForNewSale(Seller seller,Sale sale) throws Exception {
        Request request = new Request(seller,sale,RequestType.ADDING_SALE);
        dataBase.getRequests().add(request);
    }
    public boolean checkSale(Sale newSale){
        for (Sale sale : dataBase.getSales()) {
            if(sale.equals(newSale))
              return false;
        }
        return true;
    }
    public HashMap<Integer,Sale> getAllSaleWithId(int startNum){
        ArrayList<Sale> sales = dataBase.getSales();
        HashMap<Integer,Sale> allSalesWithId = new HashMap<>();
        int i=startNum;
        for (Sale sale : sales) {
            allSalesWithId.put(i,sale);
            i++;
        }
        return allSalesWithId;
    }
    public void removeSale(Sale sale) throws Exception {
        if(!checkSale(sale)){
            dataBase.getSales().remove(sale);
        }else{
            throw new Exception("This sale does't exist");
        }
    }
    public void replaceSalesGoods(ArrayList<Good> goods,Sale sale) throws Exception {
        if(!checkSale(sale)){
            sale.getGoods().clear();
            sale.getGoods().addAll(goods);
        }else{
            throw new Exception("Sale didn't found");
        }
    }
    public void updateSale(Sale sale) throws Exception {
        if(!checkSale(sale)){
            dataBase.getSales().set(sale.getOffId(),sale);
        }else{
            throw new Exception("Sale didnt found");
        }
    }
    public void setNewEndDateForSale(String endDateForSale,Sale sale) throws Exception {

        LocalDateTime endDate = LocalDateTime.parse(endDateForSale);
        sale.setEndDate(endDate);
        updateSale(sale);
}
    public void setNewStartDateForSale(String startDateForSale,Sale sale) throws Exception {
        LocalDateTime startDate = LocalDateTime.parse(startDateForSale);
        sale.setStartDate(startDate);
        updateSale(sale);
    }
    public void changeSaleAmount (int newSaleAmount,Sale sale) throws Exception {
         sale.setSaleAmount(newSaleAmount);
         updateSale(sale);
    }
    public void changeSaleStatus(SaleStatus saleStatus, Sale sale) throws Exception {
        sale.setSaleStatus(saleStatus);
        updateSale(sale);
    }
    public void addRequestForEditingSale(Seller seller,Sale sale){
        Request request = new Request(seller,sale,RequestType.EDITING_SALE);
        dataBase.getRequests().add(request);
    }



}
