package controller;

import models.DataBase.DataBase;
import models.GoodsModels.Category;
import models.GoodsModels.Comment;
import models.GoodsModels.Good;
import models.GoodsModels.Rate;
import models.Sales.Sale;
import models.Sales.SaleStatus;
import models.UsersModels.Customer;
import models.UsersModels.Seller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

public class GoodController {
     public static DataBase dataBase = DataBase.getDataBase();
     public static UserController userController = UserController.getUserController();

     private static GoodController goodController=new GoodController();

    public static GoodController getGoodController() {
        return goodController;
    }

    public HashMap<String,Good>getAllGood() throws Exception{
        if(dataBase.getGoods().isEmpty()){
            throw new Exception("There is no good in the store.");
        }else{
            return dataBase.getGoods();
        }
    }
    public HashMap<String,Category> getAllCategories()throws Exception{
        if(dataBase.getCategories().isEmpty()){
            throw new Exception("There is no Category yet");
        }else{
            return dataBase.getCategories();
        }
    }
    public Good findGoodByName(String goodName) throws Exception {
        if(dataBase.getGoods().containsKey(goodName)){
            return dataBase.getGoods().get(goodName);
        }else{
            throw new Exception("Good couldn't found");
        }
    }
    public boolean findGood(Good good) throws Exception {
        if(dataBase.getGoods().containsValue(good))
           return true;
        else{
            throw new Exception("Good couldn't found");
        }
    }
    public HashMap<Integer,Category> getCategoriesWithId(HashMap<String,Category> categories){
        int i=2;
        HashMap<Integer,Category> categoriesWithId = new HashMap<>();
        for (Category value : categories.values()) {
            categoriesWithId.put(i,value);
            i++;
        }
        return categoriesWithId;
    }

    public HashMap<String,Category> getAllMainCategories() throws Exception{
        HashMap<String,Category> mainCategories=new HashMap<>();
        for (Category category : dataBase.getCategories().values()) {
            if(category.getParentCategory()==null)
                mainCategories.put(category.getCategoryName(),category);
        }
        return mainCategories;
    }
    public HashMap<String,Category> getCategoriesWithSameParent(Category parentCategory)throws Exception{
        HashMap<String,Category> allCategories=dataBase.getCategories();
        HashMap<String,Category> categoriesWithSameParent=new HashMap<>();
        if(parentCategory==null){
            return getAllMainCategories();
        }
        for (Category value : allCategories.values()) {
            if(value.getParentCategory().equals(parentCategory))
                categoriesWithSameParent.put(value.getCategoryName(),value);
        }
        return categoriesWithSameParent;

    }
    public HashMap<Integer,Good> getGoodsWithID(HashMap<String,Good> goods){
        int i=2;
        HashMap<Integer,Good> goodsWithId = new HashMap<>();
        for (Good good : goods.values()) {
            goodsWithId.put(i,good);
            i++;
        }
        return goodsWithId;
    }
    public void removeCategory(Category category) throws Exception{

        if(dataBase.getCategories().containsValue(category)) {

            dataBase.getCategories().remove(category.getCategoryName(),category);
            category.getParentCategory().getSubCategories().remove(category.getCategoryName(),category);

        }
        else
            throw new Exception("This category doesn't exist");
    }

    public void checkIFCategoryIsSubCategory(Category parentCategory, Category subCategory) throws Exception{
        if (!parentCategory.getSubCategories().containsValue(subCategory)) {
            throw new Exception("This category is not subcategory for this");
        }
    }
    public void setParentCategoryForCategory(Category parentCategory , Category subCategory) throws Exception {
        if (parentCategory == null) {
            subCategory.setParentCategory(null);
            updateCategory(subCategory);
        } else if (parentCategory.getGoods().isEmpty()) {
            subCategory.setParentCategory(parentCategory);
            if (subCategory.getParentCategory() != null) {
                subCategory.getParentCategory().getSubCategories().remove(subCategory.getCategoryName(), subCategory);
                updateCategory(subCategory.getParentCategory());
            }
            parentCategory.getSubCategories().put(subCategory.getCategoryName(), subCategory);
            updateCategory(parentCategory);
            updateCategory(subCategory);

        } else {
            throw new Exception("This category cant be parent category because it has items  in it.");
        }
    }
    public void addCategory(String categoryName,String specialFeatures,Category parentCategory) throws Exception {
        Category category;
        if(checkCategoryName(categoryName)){
            if(parentCategory == null) {
                category = new Category(categoryName, specialFeatures, null);
            }else{
                 category = new Category(categoryName,specialFeatures,parentCategory);
                 parentCategory.getSubCategories().put(categoryName,category);
                 updateCategory(parentCategory);

            }
            dataBase.getCategories().put(categoryName,category);
        }else{
            throw new Exception("This name has been used before.");
        }

    }
    public void addSubCategory(Category category,Category subCategory) throws Exception {
        if(checkCategoryName(subCategory.getCategoryName())){
            category.getSubCategories().put(subCategory.getCategoryName(),subCategory);
            updateCategory(category);
        }
    }
    public void updateCategory(Category updatedCategory) throws Exception{
        Category category = findCategory(updatedCategory);
        dataBase.getCategories().replace(category.getCategoryName(),updatedCategory);

    }
    public Category findCategory(Category category) throws Exception {
        if(dataBase.getCategories().containsValue(category)){
            return category;
        }else{
            throw new Exception("Category couldn't find ");
        }
    }
    public void removeGood(Good good) throws Exception {
        if(findGood(good)) {
            dataBase.getGoods().remove(good.getName(), good);
            good.getCategory().getGoods().remove(good.getName(), good);
            updateCategory(good.getCategory());
        }
    }

   public Category findCategoryByName(String categoryName) throws Exception{
        if(dataBase.getCategories().containsKey(categoryName)) {
            return dataBase.getCategories().get(categoryName);
        }else{
            throw new Exception("Category couldn't found");
        }
   }
    public boolean checkCategoryName(String categoryName){
        for (String name : dataBase.getCategories().keySet()) {
            if(name.equalsIgnoreCase(categoryName))
                return false;
        }
        return true;
    }

    public ArrayList<Seller> getSellerForGood(Good good){
        return good.getSellers();
    }
    public ArrayList<Rate> getRatesForGood(Good good){
        ArrayList<Rate> rates = new ArrayList<>();
        for (Rate rate : dataBase.getRates()) {
            if(rate.getGood().equals(good))
                rates.add(rate);
        }
        return rates;
    }
    public void addComment(Customer customer , Good good , String commentText){
        Comment comment = new Comment(customer,good,commentText);
        dataBase.getComments().add(comment);
    }
    public void addRate(Customer customer , double rate , Good good) throws Exception{
        ArrayList<Rate> ratesForGood = getRatesForGood(good);
        for (Rate _rate : ratesForGood){
            if(_rate.getCustomer().equals(customer))
                throw new Exception("You have rate this good before !");
        }
        Rate newRate = new Rate(customer, rate , good);
        dataBase.getRates().add(newRate);
    }
    public ArrayList<Comment> getAllCommentForGood(Good good){
        ArrayList<Comment> comments = new ArrayList<>();
        for (Comment comment : dataBase.getComments()) {
            if(comment.getGood().equals(good))
                comments.add(comment);
        }
        return comments;
    }
    public void changeGoodName(String newName,Good good) throws Exception {
        if(findGood(good)){
            good.setName(newName);
            updateGood(good);
        }

    }
    public void updateGood(Good good) throws Exception {
        if(findGood(good)){
            dataBase.getGoods().replace(good.getName(),good);
        }
    }
    public void changeCompanyNameOfGood(String newName, Good good) throws Exception {
        if(findGood(good)){
            good.setCompanyName(newName);
            updateGood(good);
        }

    }
    public void changePriceOfGood(String newPrice, Good good) throws Exception {
        if(findGood(good)){
            int updatedPrice = Integer.parseInt(newPrice);
            good.setPrice(updatedPrice);
            updateGood(good);
        }

    }
    public void changeGoodCategory(Category category, Good good) throws Exception {
        if(findGood(good)){
            good.setCategory(category);
            updateCategory(category);
            updateGood(good);
        }

    }
    public void changeInformationForGood(String information, Good good) throws Exception {
        if(findGood(good)){
            good.setInformation(information);
            updateGood(good);
        }

    }
    public void changeNumberOfThisGoodInTheStore(int goodsNumber,Good good)throws Exception{
        if(findGood(good)){
            good.setNumbersOfGoodsInStore(goodsNumber);
            updateGood(good);
        }
    }
    public void addSellerToGood(String sellerUserName,Good good) throws Exception {
        Seller seller = userController.findSellerWithUserName(sellerUserName);
        ArrayList<Seller> sellersWithThisGood = good.getSellers();
        if(sellersWithThisGood.contains(seller)){
            throw new Exception("This Seller is already selling this goods.");
        }
        good.getSellers().add(seller);
        updateGood(good);
        userController.updateSeller(seller);
    }
    public void removeSellerFromGood(String sellerUserName,Good good) throws Exception {
        Seller seller = userController.findSellerWithUserName(sellerUserName);
        ArrayList<Seller> sellersWithThisGood = good.getSellers();
        if(sellersWithThisGood.contains(seller)){
            good.getSellers().remove(seller);
            updateGood(good);
            userController.updateSeller(seller);
        }else{
            throw new Exception("This seller isn't selling this goods");
        }
    }
    public void addGood(String goodName,String companyName,int numberOfGoodsInStore,int price ,Category category , String information) throws Exception {
        Good good = new Good(goodName,companyName,numberOfGoodsInStore,price,category,information);
        dataBase.getGoods().put(goodName,good);
        updateGood(good);
        updateCategory(category);
    }




}

