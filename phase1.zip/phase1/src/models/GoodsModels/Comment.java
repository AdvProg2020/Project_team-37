package models.GoodsModels;

import controller.UserController;
import models.Logs.ShoppingLog;
import models.UsersModels.Customer;

import java.util.ArrayList;

public class Comment {
    private Customer customer;
    private Good good;
    private String commentText;
    private CommentStatus commentStatus;
    private boolean isBoughtByThisCustomer;

    public Comment(Customer customer, Good good, String commentText) {
        this.customer = customer;
        this.good = good;
        this.commentText = commentText;
        this.isBoughtByThisCustomer = isBoughtByThisCustomer();
        this.commentStatus=CommentStatus.PROCESSING;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Good getGood() {
        return good;
    }

    public String getCommentText() {
        return commentText;
    }

    public CommentStatus getCommentStatus() {
        return commentStatus;
    }

    public boolean isBoughtByThisCustomer() {
        ArrayList<ShoppingLog> shoppingHistory = customer.getShoppingHistories();
        for (ShoppingLog shoppingLog : shoppingHistory) {
            if(shoppingLog.getGoodsList().keySet().contains(good))
                return true;
        }
        return false;
    }

    public void setCommentStatus(CommentStatus commentStatus) {
        this.commentStatus = commentStatus;
    }

}
