package models.GoodsModels;

public enum CommentStatus {
    ACCEPTED,PROCESSING,REJECTED_BY_MANAGER
}
