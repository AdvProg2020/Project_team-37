package models.GoodsModels;

import java.util.ArrayList;
import java.util.HashMap;

public class Category {
    private String categoryName;
    private String specialFeatures;
    private HashMap<String,Category> subCategories;
    private HashMap<String,Good> goods;
    private Category parentCategory;

    public Category(String categoryName, String specialFeatures, Category parentCategory) {
        this.categoryName = categoryName;
        this.specialFeatures = specialFeatures;
        this.parentCategory = parentCategory;
        this.subCategories=new HashMap<>();
        this.goods=new HashMap<>();
    }

    public String getCategoryName() {
        return categoryName;
    }

    public String getSpecialFeatures() {
        return specialFeatures;
    }

    public HashMap<String, Category> getSubCategories() {
        return subCategories;
    }

    public HashMap<String, Good> getGoods() {
        return goods;
    }

    public Category getParentCategory() {
        return parentCategory;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public void setSpecialFeatures(String specialFeatures) {
        this.specialFeatures = specialFeatures;
    }

    public void setParentCategory(Category parentCategory) {
        this.parentCategory = parentCategory;
    }
}
