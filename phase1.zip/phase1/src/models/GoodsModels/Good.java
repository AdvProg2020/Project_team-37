package models.GoodsModels;

import controller.GoodController;
import models.DataBase.DataBase;
import models.Sales.SaleStatus;
import models.UsersModels.Seller;

import java.util.ArrayList;
import java.util.HashMap;

public class Good {
    private String goodId;
    private SaleStatus goodStatus;
    private String name;
    private String companyName;
    private int price;
    private ArrayList<Seller> sellers;//should be initialize when good is made.
    private boolean isAvailable;
    private Category category;
    private String information;
    private double averageRate;
    private ArrayList<Comment>comments;
    private int numbersOfGoodsInStore;

    public Good(String name, String companyName,int numbersOfGoodsInStore, int price, Category category, String information) {
        this.name = name;
        this.companyName = companyName;
        this.price = price;
        this.category = category;
        this.information = information;
        this.comments=new ArrayList<>();
        this.sellers=new ArrayList<>();
        this.numbersOfGoodsInStore = numbersOfGoodsInStore;
        this.isAvailable = isAvailable();
        try {
            this.goodId = getGoodId();
        } catch (Exception ignored) {

        }
        this.averageRate = getAverageRate();

    }

   public String getGoodId() throws Exception {
        HashMap<String,Good> goodsInStore = DataBase.getDataBase().getGoods();
        if(!goodsInStore.isEmpty()){
            return String.valueOf((DataBase.getDataBase().getGoods().size() + 1));
        }else
            throw new Exception("There is no item here yet!");
    }

    public SaleStatus getGoodStatus() {
        return goodStatus;
    }

    public String getName() {
        return name;
    }

    public String getCompanyName() {
        return companyName;
    }

    public int getPrice() {
        return price;
    }

    public ArrayList<Seller> getSellers() {
        return sellers;
    }

    public boolean isAvailable() {
        if(numbersOfGoodsInStore>0)
            return true;
            else
                return false;
    }

    public Category getCategory() {
        return category;
    }

    public String getInformation() {
        return information;
    }

    public double setAverageRate(){
        double sumOfRates =0 ;
        ArrayList<Rate> rates = GoodController.getGoodController().getRatesForGood(this);
        int i=1;
        for (Rate rate : rates) {
            sumOfRates = sumOfRates + rate.getRate();
            i++;
        }
        return sumOfRates/i;
    }

    public double getAverageRate() {
        return averageRate;
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    public void setGoodStatus(SaleStatus goodStatus) {
        this.goodStatus = goodStatus;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public void setInformation(String information) {
        this.information = information;
    }

    public int getNumbersOfGoodsInStore() {
        return numbersOfGoodsInStore;
    }

    public void setNumbersOfGoodsInStore(int numbersOfGoodsInStore) {
        this.numbersOfGoodsInStore = numbersOfGoodsInStore;
    }

    public void setName(String name) {
        this.name = name;
    }
}
