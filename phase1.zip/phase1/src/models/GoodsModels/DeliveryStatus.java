package models.GoodsModels;

public enum  DeliveryStatus {
    DELIVERED,DELIVERING,PROCESSING
}
