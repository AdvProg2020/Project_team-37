package models.GoodsModels;
import models.UsersModels.Customer;

public class Rate {
    private Customer customer;
    private double rate;
    private Good good;

    public Rate(Customer customer, double rate, Good good) {
        this.customer = customer;
        this.rate = rate;
        this.good = good;
    }

    public Customer getCustomer() {
        return customer;
    }

    public double getRate() {
        return rate;
    }

    public Good getGood() {
        return good;
    }
}
