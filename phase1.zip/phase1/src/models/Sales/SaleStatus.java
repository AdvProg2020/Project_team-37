package models.Sales;

public enum SaleStatus {
    CONFIRMED,WAITING_FOR_EDIT,WAITING_TO_MAKE
}
