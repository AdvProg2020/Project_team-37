package models.Sales;

import models.DataBase.DataBase;
import models.GoodsModels.Good;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

public class Sale {
    private int offId;
    private ArrayList<Good>goods;
    private SaleStatus saleStatus;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private int saleAmount;
    public Sale(ArrayList<Good> goods,int saleAmount, SaleStatus saleStatus, String startDate, String endDate) {
        try {
            this.offId = getSaleID();
        } catch (Exception ignore) {

        }
        this.goods = goods;
        this.saleStatus = saleStatus;
        this.startDate = LocalDateTime.parse(startDate);
        this.endDate = LocalDateTime.parse(endDate);
        this.saleAmount=saleAmount;
    }

    public int getOffId() {
        return offId;
    }

    public ArrayList<Good> getGoods() {
        return goods;
    }

    public SaleStatus getSaleStatus() {
        return saleStatus;
    }


    public int getSaleAmount() {
        return saleAmount;
    }

    public void setSaleStatus(SaleStatus saleStatus) {
        this.saleStatus = saleStatus;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public void setSaleAmount(int saleAmount) {
        this.saleAmount = saleAmount;
    }

    public int getSaleID() throws Exception {
        ArrayList<Sale> allSales = DataBase.getDataBase().getSales();
        if(!allSales.isEmpty()){
            return DataBase.getDataBase().getSales().size();
        }else
            throw new Exception("There is no item here yet!");
    }
}
