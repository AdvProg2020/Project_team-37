package models.Sales;

import models.UsersModels.Customer;

import java.time.LocalDate;
import java.util.ArrayList;

public class Discount {
    private String discountCode;
    private LocalDate startDate;
    private LocalDate endDate;
    private int discountAmount;
    private int limitPerPerson;
    private ArrayList<Customer> customers;

    public Discount(LocalDate startDate, LocalDate endDate, int discountAmount, int limitPerPerson,String discountCode) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.discountAmount = discountAmount;
        this.limitPerPerson = limitPerPerson;
        this.discountCode=discountCode;
        this.customers=new ArrayList<>();
    }

    public String getDiscountCode() {
        return discountCode;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public int getDiscountAmount() {
        return discountAmount;
    }

    public int getLimitPerPerson() {
        return limitPerPerson;
    }

    public ArrayList<Customer> getCustomers() {
        return customers;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public void setDiscountAmount(int discountAmount) {
        this.discountAmount = discountAmount;
    }

    public void setLimitPerPerson(int limitPerPerson) {
        this.limitPerPerson = limitPerPerson;
    }
}
