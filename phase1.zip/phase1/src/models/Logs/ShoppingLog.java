package models.Logs;

import models.GoodsModels.DeliveryStatus;
import models.GoodsModels.Good;
import models.UsersModels.Customer;
import models.UsersModels.Seller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class ShoppingLog {
    private String shoppingLogId;
    private Date date;
    private int paidAmount;
    private int discountAmount;
    private HashMap<Good,Integer> goodsList;
    private Customer customer;
    private Seller seller;
    private DeliveryStatus deliveryStatus;

    public ShoppingLog(int paidAmount, int discountAmount, Seller seller,Customer customer) {
        this.paidAmount = paidAmount;
        this.discountAmount = discountAmount;
        this.goodsList = new HashMap<>();
        this.seller = seller;
        this.customer = customer;
        this.date=new Date();
        this.deliveryStatus=DeliveryStatus.PROCESSING;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getShoppingLogId() {
        return shoppingLogId;
    }

    public Date getDate() {
        return date;
    }

    public int getPaidAmount() {
        return paidAmount;
    }

    public int getDiscountAmount() {
        return discountAmount;
    }

    public HashMap<Good, Integer> getGoodsList() {
        return goodsList;
    }

    public Seller getSeller() {
        return seller;
    }

    public DeliveryStatus getDeliveryStatus() {
        return deliveryStatus;
    }

    public void setPaidAmount(int paidAmount) {
        this.paidAmount = paidAmount;
    }

    public void setDiscountAmount(int discountAmount) {
        this.discountAmount = discountAmount;
    }

    public void setSeller(Seller seller) {
        this.seller = seller;
    }

    public void setDeliveryStatus(DeliveryStatus deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

}
