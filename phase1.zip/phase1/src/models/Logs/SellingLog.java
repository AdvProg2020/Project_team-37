package models.Logs;

import models.GoodsModels.DeliveryStatus;
import models.GoodsModels.Good;
import models.UsersModels.Customer;

import java.util.Date;
import java.util.HashMap;

public class SellingLog {
    private String sellingLogId;
    private Date date;
    private int receivedAmount;
    private int discountedAmount;
    private Customer customer;
    private HashMap<Good,Integer> goodsList;
    private DeliveryStatus deliveryStatus;

    public SellingLog(int receivedAmount, int discountedAmount, Customer customer) {
        this.receivedAmount = receivedAmount;
        this.discountedAmount = discountedAmount;
        this.customer = customer;
        this.goodsList = new HashMap<>();
        this.date=new Date();
        this.deliveryStatus=DeliveryStatus.PROCESSING;

    }

    public String getSellingLogId() {
        return sellingLogId;
    }

    public Date getDate() {
        return date;
    }

    public int getReceivedAmount() {
        return receivedAmount;
    }

    public int getDiscountedAmount() {
        return discountedAmount;
    }

    public Customer getCustomer() {
        return customer;
    }

    public HashMap<Good, Integer> getGoodsList() {
        return goodsList;
    }

    public DeliveryStatus getDeliveryStatus() {
        return deliveryStatus;
    }

    public void setReceivedAmount(int receivedAmount) {
        this.receivedAmount = receivedAmount;
    }

    public void setDiscountedAmount(int discountedAmount) {
        this.discountedAmount = discountedAmount;
    }

    public void setDeliveryStatus(DeliveryStatus deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }
}

