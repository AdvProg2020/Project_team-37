package models.Logs;

import models.GoodsModels.Good;

import java.util.HashMap;

public class ShoppingCart {
    private HashMap<Good,Integer> goodsInCredit;
    private double totalPrice;

    public ShoppingCart() {
        this.goodsInCredit = new HashMap<>();
        this.totalPrice = 0;
    }

    public double getTotalPrice() {
        double totalPrice=0;
        for (Good good : goodsInCredit.keySet()) {
            double goodPrice = good.getPrice();
            int goodAmount = goodsInCredit.get(good);
            totalPrice +=goodAmount*goodPrice;
        }
        return totalPrice;
    }


    public HashMap<Good, Integer> getGoodInCart() {
        return goodsInCredit;
    }
}
