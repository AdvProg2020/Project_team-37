package models.Requests;

public enum  RequestType {
    //seller request

    ADDING_SELLER,

    //goods requests

    EDITING_GOOD,
    ADDING_GOOD,
    REMOVING_GOOD,

    //sale requests

    ADDING_SALE,
    EDITING_SALE,
    REMOVING_SALE,

    //discount requests

    ADDING_DISCOUNT,
    EDITING_DISCOUNT,
    REMOVING_DISCOUNT,

}
