package models.Requests;

import models.GoodsModels.Good;
import models.Sales.Discount;
import models.Sales.Sale;
import models.UsersModels.Seller;

public  class Request {
    private RequestType requestType;
    private RequestStatus requestStatus;
    private Good good ;
    private Seller seller;
    private Sale sale;

    public Request(Seller seller){
        this.requestType = RequestType.ADDING_SALE;
        this.seller = seller;
        this.requestStatus = RequestStatus.PROCESSING;
    }
    public Request(Seller seller,Good good,RequestType requestType){
        this.seller = seller;
        this.requestType = requestType;
        this.good = good;
        this.requestStatus = RequestStatus.PROCESSING;
    }
    public Request(Seller seller,Sale sale,RequestType requestType){
        this.sale = sale;
        this.seller = seller;
        this.requestType = requestType;
        this.requestStatus = RequestStatus.PROCESSING;
    }

    public Good getGood() {
        return good;
    }

    public Seller getSeller() {
        return seller;
    }


    public Sale getSale() {
        return sale;
    }

    public RequestType getRequestType() {
        return requestType;
    }

    public RequestStatus getRequestStatus() {
        return requestStatus;
    }

    public void setRequestType(RequestType requestType) {
        this.requestType = requestType;
    }

    public void setRequestStatus(RequestStatus requestStatus) {
        this.requestStatus = requestStatus;
    }
}

