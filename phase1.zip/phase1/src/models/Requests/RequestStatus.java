package models.Requests;

public enum RequestStatus {
    ACCEPTED,REJECTED,PROCESSING
}
