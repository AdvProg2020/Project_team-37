package models.DataBase;

import models.GoodsModels.Category;
import models.GoodsModels.Comment;
import models.GoodsModels.Good;
import models.GoodsModels.Rate;
import models.Logs.SellingLog;
import models.Logs.ShoppingLog;
import models.Requests.Request;
import models.Sales.Discount;
import models.Sales.Sale;
import models.Sales.SaleStatus;
import models.UsersModels.*;

import java.util.ArrayList;
import java.util.HashMap;

public class DataBase {
    private static  DataBase dataBase=new DataBase();

    public static DataBase getDataBase() {
        return dataBase;
    }
    private HashMap<String, Account> accounts;
    private HashMap<String, Seller> sellers;
    private HashMap<String, Customer> customers;
    private HashMap<String, Discount> discounts;
    private ArrayList<Comment> comments;
    private HashMap<String, Good>goods;
    private HashMap<String, Manager> managers;
    private ArrayList<Request> requests;
    private ArrayList<Rate> rates;
    private ArrayList<Sale> sales;
    private HashMap<String, SellingLog> sellingLogs;
    private HashMap<String, ShoppingLog> shoppingLogs;

    private HashMap<String, Category> categories;

    private DataBase() {
        this.accounts = new HashMap<>();
        this.sellers = new HashMap<>();
        this.customers = new HashMap<>();
        this.discounts = new HashMap<>();
        this.comments = new ArrayList<>();
        this.goods = new HashMap<>();
        this.managers = new HashMap<>();
        this.rates = new ArrayList<>();
        this.sales = new ArrayList<>();
        this.sellingLogs = new HashMap<>();
        this.requests = new ArrayList<>();
        this.shoppingLogs = new HashMap<>();
        this.categories=new HashMap<>();
        Manager firstManager = new Manager("shayan", "shayan", "shabanzadeh", "shayanshabanzadeh0@gmail.com", "09120803364", "123", AccountType.MANAGER);
        this.managers.put("shayan", firstManager);
        Category category1 = new Category("milk", "cold", null);
        this.categories.put("milk", category1);
        Category category2 = new Category("sib", "colder", category1);
        this.categories.put("sib", category2);
        Good good=new Good("havij","javad",1000,10000,category2,"hichi");
        this.goods.put(good.getName(),good);
        Good good1 = new Good("Khorma","Javad2",200000,1000,category2 , "kheilie khoshmaze");
        this.goods.put(good1.getName(),good1);
        ArrayList<Good> goods = new ArrayList<>();
        goods.add(good);
        ArrayList<Good> goods1 = new ArrayList<>();
        goods1.add(good1);
        Sale sale = new Sale(goods,30, SaleStatus.CONFIRMED,"2018-02-13T06:30","2018-02-19T06:30");
        Sale sale1 = new Sale(goods1,35, SaleStatus.CONFIRMED,"2018-02-16T06:30","2018-02-19T06:30");
        this.sales.add(sale);
        this.sales.add(sale1);
        Seller amin = new Seller("amin","amin","ghodoosiyan","amin@gmail.com","09121111111","123",AccountType.SELLER,"Khiyar ha");
        this.getSellers().put(amin.getUserName(),amin);
        category1.getSubCategories().put(category2.getCategoryName(),category2);
        category2.getGoods().put(good.getName(),good);



    }



    public HashMap<String, Account> getAccounts() {
        return accounts;
    }

    public ArrayList<Request> getRequests() {
        return requests;
    }

    public HashMap<String, Seller> getSellers() {
        return sellers;
    }

    public HashMap<String, Customer> getCustomers() {
        return customers;
    }

    public HashMap<String, Discount> getDiscounts() {
        return discounts;
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    public HashMap<String, Good> getGoods() {
        return goods;
    }

    public HashMap<String, Manager> getManagers() {
        return managers;
    }

    public ArrayList<Rate> getRates() {
        return rates;
    }

    public ArrayList<Sale> getSales() {
        return sales;
    }

    public HashMap<String, SellingLog> getSellingLogs() {
        return sellingLogs;
    }

    public HashMap<String, ShoppingLog> getShoppingLogs() {
        return shoppingLogs;
    }

    public HashMap<String, Category> getCategories() {
        return categories;
    }
}
