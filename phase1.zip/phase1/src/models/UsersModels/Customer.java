package models.UsersModels;

import models.Logs.ShoppingCart;
import models.Logs.ShoppingLog;

import java.util.ArrayList;


public class Customer extends Account {

    private ShoppingCart shoppingCart;
    private ArrayList<ShoppingLog> shoppingHistories;
    private double credit;

    public Customer(String userName, String firstName, String lastName, String emailAddress, String telephoneNumber, String password, AccountType accountType) {
        super(userName, firstName, lastName, emailAddress, telephoneNumber, password, accountType);
        this.shoppingCart = new ShoppingCart();
        this.shoppingHistories = new ArrayList<>();
        this.credit = 0;
    }


    public ShoppingCart getShoppingCart() {
        return shoppingCart;
    }

    public ArrayList<ShoppingLog> getShoppingHistories() {
        return shoppingHistories;
    }

    public double getCredit() {
        return credit;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }


}
