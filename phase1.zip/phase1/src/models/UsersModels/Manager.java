package models.UsersModels;

public class Manager extends Account {
    public Manager(String userName, String firstName, String lastName, String emailAddress, String telephoneNumber, String password, AccountType accountType) {
        super(userName, firstName, lastName, emailAddress, telephoneNumber, password, accountType);
    }
}
