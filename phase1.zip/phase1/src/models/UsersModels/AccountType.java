package models.UsersModels;

public enum AccountType {
    MANAGER, SELLER,CUSTOMER
}
