package models.UsersModels;

import models.GoodsModels.Good;
import models.Logs.SellingLog;
import models.UsersModels.Account;
import models.UsersModels.AccountType;

import java.util.ArrayList;

public class Seller extends Account {
    private String companyName;
    private ArrayList<SellingLog> sellingHistories;
    private ArrayList<Good> goodsForSell;
    public Seller(String userName, String firstName, String lastName, String emailAddress, String telephoneNumber, String password, AccountType accountType, String companyName) {
        super(userName, firstName, lastName, emailAddress, telephoneNumber, password, accountType);
        this.companyName=companyName;
        this.sellingHistories = new ArrayList<>();
        this.goodsForSell = new ArrayList<>();
        
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
