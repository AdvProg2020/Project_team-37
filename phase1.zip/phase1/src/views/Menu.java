package views;

import controller.GoodController;
import controller.SaleController;
import controller.UserController;
import models.UsersModels.Account;

import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class Menu {
    protected String menuName;
    protected Menu parentMenu;
    protected HashMap<Integer,Menu> subMenus;
    protected   Scanner scanner;
    protected UserController userController;
    protected GoodController goodController;
    protected SaleController saleController;
    public Menu(String menuName, Menu parentMenu) {
        this.menuName = menuName;
        this.parentMenu = parentMenu;
        this.subMenus=new HashMap<>();
        setScanner(View.scanner);
        setUserController(View.userController);
        setGoodController(View.goodController);
        setSaleController(View.saleController);
    }

    public void setGoodController(GoodController goodController) {
        this.goodController = goodController;
    }

    public void setSaleController(SaleController saleController) {
        this.saleController = saleController;
    }

    public void setUserController(UserController userController) {
        this.userController = userController;
    }

    public void setScanner(Scanner scanner) {
        this.scanner = scanner;
    }

    public String getMenuName() {
        return menuName;
    }

    public Menu getParentMenu() {
        return parentMenu;
    }

    public HashMap<Integer,Menu> getSubMenus() {
        return subMenus;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public void setParentMenu(Menu parentMenu) {
        this.parentMenu = parentMenu;
    }

    public void show(){
        System.out.println(menuName+":");
        for (Integer number : subMenus.keySet()) {
            System.out.println(number+"."+subMenus.get(number).menuName);
        }
        if(this.parentMenu==null){
            System.out.println((subMenus.size()+1)+".Exit");
        }else{
            System.out.println((subMenus.size()+1)+".Back");
        }
    }


    public void execute()  {
        System.out.println("Enter a number:");
        Menu nextMenu=null;
        int input;

        while (true){
            input=Integer.parseInt(inputFormat("^\\d+$").trim());
            if(input>0 && input<=subMenus.size()+1)
                break;
            else{
                System.out.println("Invalid input");
            }
        }
         if(input<subMenus.size()+1 && input>0){
            nextMenu=subMenus.get(input);
        }else if(input==subMenus.size()+1){
            if(this.parentMenu==null){
                System.exit(1);
            }else{
                nextMenu=parentMenu;
            }
        }
        nextMenu.show();
        nextMenu.execute();

    }
    public  String inputFormat(String regex) {
       return inputFormatWithHelpText(regex,"");
    }

    public String inputFormatWithHelpText(String regex,String helpText){
        Pattern pattern=Pattern.compile(regex);
        String input;
        System.out.println(helpText);
        while(true) {
            input= scanner.nextLine();
            Matcher matcher = pattern.matcher(input);
            if (matcher.find()) {
                break;
            } else{
                System.out.println("Invalid input.");
            }
        }
        return input;
    }


}

