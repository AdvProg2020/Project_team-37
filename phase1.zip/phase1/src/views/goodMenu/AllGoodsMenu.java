package views.goodMenu;

import models.GoodsModels.Good;
import views.Menu;

import java.util.HashMap;

public class AllGoodsMenu extends Menu {
    public AllGoodsMenu( Menu parentMenu) {
        super("All goods", parentMenu);
    }

    @Override
    public void show() {
        super.show();
        System.out.println("-----------------");
        try {
            showAllGoods();
        }catch (Exception e){
            System.out.println("There is no good in this store.");
        }
    }

    @Override
    public void execute() {
        Menu nextMenu=this;
        HashMap<Integer,Good> goodsWithNumber = getGoodsWithNumber();
        int input=Integer.parseInt(inputFormatWithHelpText("\\d+","Enter a number:"));
        if(input==1) {
            nextMenu = parentMenu;
        }else if(input>1 && input<= goodsWithNumber.size()+1){
            Good good = goodsWithNumber.get(input);
            nextMenu = new GoodMenu(good,this);
        }else {
            System.out.println("Invalid input!");
        }
        nextMenu.show();
        nextMenu.execute();
    }

    protected void showAllGoods() throws  Exception{
        int i = 2;
            HashMap<String, Good> goods = goodController.getAllGood();
            for (String goodsName : goods.keySet()) {
                System.out.println(i + "." + goodsName);
                i++;
            }
    }
    protected HashMap<Integer,Good> getGoodsWithNumber(){
        int i=2;
        HashMap<Integer,Good> goodsWithNumber = new HashMap<>();
        try {
            HashMap<String,Good> goods = goodController.getAllGood();
            for (Good good : goods.values()) {
                goodsWithNumber.put(i,good);
                i++;
            }
        }catch(Exception ignore){

        }
        return goodsWithNumber;
    }
}
