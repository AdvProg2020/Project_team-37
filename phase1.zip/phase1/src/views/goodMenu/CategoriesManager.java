package views.goodMenu;

import models.GoodsModels.Category;
import models.GoodsModels.Good;
import views.Menu;

import java.util.HashMap;

public class CategoriesManager extends CategoriesMenu {

    private Category category ;
    private HashMap<Integer,Category> subCategoriesWithId;
    private HashMap<Integer,Good> goodsWithId;
    public CategoriesManager(Category category, Menu parentMenu) {
        super(category, parentMenu);
        this.category = category;
        this.subCategoriesWithId = getSubCategoriesWithId();
        this.goodsWithId = getGoodsWithId();
    }

    @Override
    public void show() {
        subCategoriesWithId.clear();
        subCategoriesWithId = getSubCategoriesWithId();
        goodsWithId.clear();
        goodsWithId = getGoodsWithId();
        System.out.println("Enter a category number to see subcategories or press 1 to return or manage these categories.");
        if(category == null ){
            System.out.println("                           MAIN CATEGORIES : " );
        }else{
            System.out.println("                  CATEGORY : " + category.getCategoryName());
        }
        System.out.println();
        System.out.println("1.Back");
        System.out.println("-----------------------------------SUBCATEGORIES-----------------------------------------------");
        try {
            showCategories(subCategoriesWithId);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("-----------------------------------GOODS IN THIS CATEGORY--------------------------------------");
        try {
            showGoodsInCategory();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("-----------------------------------CATEGORIES MANAGER------------------------------------------");
        showFieldsForManaging();
    }

    @Override
    public void execute() {
        Menu nextMenu = this;
        int startNumberForManaging = getStartNumberForManaging();
        int endNumberForCategoriesOrGood = getEndNumberForGoodsOrCategories();
        int input = Integer.parseInt(inputFormat("\\d+"));
        if(input == 1){
            nextMenu = parentMenu;
        }else if(input>1 && input <= endNumberForCategoriesOrGood){
            if(subCategoriesWithId.isEmpty()){
                Good good = goodsWithId.get(input);
                nextMenu = new GoodManager(good,this);
            }else{
                Category nextCategory = subCategoriesWithId.get(input);
                nextMenu = new CategoriesManager(nextCategory,this);
            }
        }else if(input ==startNumberForManaging ){
            if(category == null){
                System.out.println("You cant edit here chose a category and then edit.");

            }else {
                nextMenu = new Menu("Edit category", this) {
                    @Override
                    public void show() {
                        System.out.println("1.Back");
                        System.out.println("2.Change categories name");
                        System.out.println("3.Change special features");
                        System.out.println("4.Add subCategories");
                        System.out.println("5.Remove Sub Categories");
                        System.out.println("6.Change parent category");
                        System.out.println("7.Add Good to this category");
                    }

                    @Override
                    public void execute() {
                        Menu nextMenu = this;
                        int input = Integer.parseInt(inputFormatWithHelpText("\\d+", "Enter a number:"));
                        if (input == 1) {
                            nextMenu = parentMenu;
                        } else if (input == 2) {
                            System.out.println("1.Back");
                            String categoryNewName = inputFormatWithHelpText(".+", "New name:");
                            if (!categoryNewName.equalsIgnoreCase("1".trim())) {
                                category.setCategoryName(categoryNewName);
                                try {
                                    goodController.updateCategory(category);
                                    System.out.println("Confirmed!");
                                } catch (Exception e) {
                                    System.out.println(e.getMessage());
                                }
                            }
                        } else if (input == 3) {
                            System.out.println("1.Back");
                            String categoryNewSpecialFeatures = inputFormatWithHelpText(".+", "Special feature:");
                            if (!categoryNewSpecialFeatures.equalsIgnoreCase("1".trim())) {
                                category.setSpecialFeatures(categoryNewSpecialFeatures);
                                try {
                                    goodController.updateCategory(category);
                                    System.out.println("Confirmed!");
                                } catch (Exception e) {
                                    System.out.println(e.getMessage());
                                }
                            }
                        } else if (input == 4) {
                            System.out.println("1.Back");
                            String subCategoryName = inputFormatWithHelpText(".+", "Subcategory name:");
                            String specialFeature = inputFormatWithHelpText(".+", "Special feature:");
                            if (!(subCategoryName.equalsIgnoreCase("1".trim()) && specialFeature.equalsIgnoreCase("1".trim()))) {
                                Category subCategory = new Category(subCategoryName, specialFeature, category);
                                try {
                                    goodController.addSubCategory(category, subCategory);
                                    System.out.println("Confirmed!");
                                } catch (Exception e) {
                                    System.out.println(e.getMessage());
                                }
                            }
                        } else if (input == 5) {
                            String subCategoryName = inputFormatWithHelpText(".+", "Category's Name:");
                            if (!subCategoryName.equalsIgnoreCase("1".trim())) {
                                try {
                                    Category subCategory = goodController.findCategoryByName(subCategoryName);
                                    goodController.checkIFCategoryIsSubCategory(category, subCategory);
                                    goodController.removeCategory(subCategory);
                                    System.out.println("Confirmed!");
                                } catch (Exception e) {
                                    System.out.println(e.getMessage());
                                }
                            }

                        } else if (input == 6) {
                            Category parentCategory;
                            String parentCategoryName = inputFormatWithHelpText(".+", "Category's Name: | write main category to add to main categories.");
                            if (!parentCategoryName.equalsIgnoreCase("1".trim())) {
                                try {
                                    if(parentCategoryName.equalsIgnoreCase("main category".trim())){
                                        goodController.setParentCategoryForCategory(null, category);
                                    }else {
                                        parentCategory = goodController.findCategoryByName(parentCategoryName);
                                        goodController.setParentCategoryForCategory(parentCategory, category);
                                    }
                                    System.out.println("Confirmed!");
                                } catch (Exception e) {
                                    System.out.println(e.getMessage());
                                }

                            }
                        } else if (input == 7) {
                            if (category.getSubCategories().isEmpty()) {
                                String goodsName = inputFormatWithHelpText(".+", "Good's Name:");
                                if (!goodsName.equalsIgnoreCase("1".trim())) {
                                    try {
                                        Good good = goodController.findGoodByName(goodsName);
                                        category.getGoods().put(goodsName, good);
                                        goodController.updateCategory( category);
                                        System.out.println("Confirmed!");
                                    } catch (Exception e) {
                                        System.out.println(e.getMessage());
                                    }
                                }
                            } else {
                                System.out.println("This category cant have goods in it cause it has subcategories.");
                            }
                        }
                        nextMenu.show();
                        nextMenu.execute();
                    }
                };
            }
        }else if(input == startNumberForManaging + 1){
            String categoryName = inputFormatWithHelpText(".+","Category Name:");
            String specialFeature = inputFormatWithHelpText(".+","Special Feature:");
            try {
                goodController.addCategory(categoryName,specialFeature,category);
                subCategoriesWithId = getSubCategoriesWithId();
                System.out.println("Category has successfully added to store.");
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }else if(input == startNumberForManaging +2){
          nextMenu= new Menu("Remove Category",this) {
              @Override
              public void show() {
                  subCategoriesWithId.clear();
                  subCategoriesWithId = getSubCategoriesWithId();
                  System.out.println("1.Back");
                  try {
                      showCategories(subCategoriesWithId);
                  } catch (Exception e) {
                      System.out.println(e.getMessage());
                  }
              }

              @Override
              public void execute() {
                  Menu nextMenu = this;
                  int input = Integer.parseInt(inputFormat("\\d+"));
                  if(input == 1 ){
                      nextMenu = parentMenu;
                  }else if(input > 1 && input <= subCategoriesWithId.size()+1){
                      Category category1 = subCategoriesWithId.get(input);
                      try {
                          goodController.removeCategory(category1);
                          subCategoriesWithId = getSubCategoriesWithId();
                          System.out.println("Category has successfully deleted.");
                      } catch (Exception e) {
                          System.out.println(e.getMessage());
                      }
                  }
                  nextMenu.show();
                  nextMenu.execute();
              }
          };

        }else{
            System.out.println("Invalid command!");
        }
        nextMenu.show();
        nextMenu.execute();
    }
    private void showFieldsForManaging(){
        int startPointNumber = getStartNumberForManaging();
            System.out.println(startPointNumber + "." + "Edit  a category");
            System.out.println((startPointNumber+1) + "." + "Add a category ");
            System.out.println((startPointNumber+2) + "." + "Remove a category");

    }
    private  int getStartNumberForManaging(){
        int startPointNumber;
        if(subCategoriesWithId.isEmpty()){
            startPointNumber = category.getGoods().size()+2;
        }else{
            startPointNumber = subCategoriesWithId.size()+2;
        }
        return startPointNumber;
    }
    private int getEndNumberForGoodsOrCategories(){
        int endNumber;
        if(subCategoriesWithId.isEmpty()){
            endNumber = category.getGoods().size()+1;
        }else{
            endNumber = subCategoriesWithId.size()+1;
        }
        return endNumber;
    }
    private void showCategories(HashMap<Integer,Category> categories) throws Exception {
        if(categories.isEmpty())
            throw new Exception("There is no category here yet.");
        else{
            for (Integer integer : categories.keySet()) {
                System.out.println(integer+"."+categories.get(integer).getCategoryName());
            }
        }
    }


}
