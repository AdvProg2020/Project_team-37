package views.goodMenu;

import views.MainMenu;
import views.Menu;

public class GoodsMenu extends Menu {
    public GoodsMenu( Menu parentMenu) {
        super("Goods page", parentMenu);
        subMenus.put(1,new CategoriesMenu(null,this));
        subMenus.put(2,new AllGoodsMenu(this));
    }
}
