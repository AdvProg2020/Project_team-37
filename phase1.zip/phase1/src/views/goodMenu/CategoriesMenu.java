package views.goodMenu;
import models.GoodsModels.Category;
import models.GoodsModels.Good;
import models.UsersModels.Account;
import models.UsersModels.AccountType;
import views.Menu;

import java.util.HashMap;


public class CategoriesMenu extends Menu {
    protected Category category;
    protected HashMap<Integer,Category> subCategoriesWithId;
    protected HashMap<Integer, Good> goodsWithId;


    public CategoriesMenu( Category category, Menu parentMenu) {
        super("Category Page", parentMenu);
        this.category = category;
        this.goodsWithId = getGoodsWithId();
        this.subCategoriesWithId = getSubCategoriesWithId();
    }

    @Override
    public void show() {
        System.out.println("1.Back");
        if(!subCategoriesWithId.isEmpty())
        showSubCategories();
        else{
            try {
                showGoodsInCategory();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }

    }

    @Override
    public void execute() {
        Menu nextMenu = this;
        int input = Integer.parseInt(inputFormatWithHelpText("\\d+", "Enter a number:"));
        if (input == 1)
            nextMenu = parentMenu;
        if (subCategoriesWithId.isEmpty()) {
            if (input > 1 && input <= goodsWithId.size() + 1) {
                Good good = goodsWithId.get(input);
                nextMenu = new GoodMenu(good, this);
            }


        } else {
            if (input > 1 && input <= subCategoriesWithId.size() + 1) {
                Category nextCategory = subCategoriesWithId.get(input);
                nextMenu = new CategoriesMenu(nextCategory, this);
            }
        }


        nextMenu.show();
        nextMenu.execute();
    }

    protected void showSubCategories(){
        for (Integer integer : subCategoriesWithId.keySet()) {
            System.out.println(integer+"."+subCategoriesWithId.get(integer).getCategoryName());
        }
    }

    public Category getCategory() {
        return category;
    }

    protected HashMap<Integer,Category> getSubCategoriesWithId(){
        HashMap<Integer,Category> subCategoriesWithId = new HashMap<>();
        if(category == null){
            try {
                HashMap<String,Category> mainCategories = goodController.getAllMainCategories();
                subCategoriesWithId = goodController.getCategoriesWithId(mainCategories);
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }else {
            subCategoriesWithId = goodController.getCategoriesWithId(category.getSubCategories());
        }
        return subCategoriesWithId;
    }
    protected void showGoodsInCategory() throws Exception{
        if(goodsWithId.size()==0)
            throw new Exception("There is no good in this category yet!");
        else {
            for (Integer integer : goodsWithId.keySet()) {
                System.out.println(integer + "." + goodsWithId.get(integer).getName());
            }
        }
    }
    protected HashMap<Integer, Good> getGoodsWithId(){
        if(category == null)
            return new HashMap<Integer,Good>();
        else {
            HashMap<Integer, Good> goodsWithId = new HashMap<>();
            goodsWithId = goodController.getGoodsWithID(category.getGoods());
            return goodsWithId;
        }
    }







}

