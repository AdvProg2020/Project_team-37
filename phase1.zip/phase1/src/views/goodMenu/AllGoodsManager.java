package views.goodMenu;

import models.GoodsModels.Category;
import models.GoodsModels.Good;
import views.Menu;

import java.util.HashMap;

public class AllGoodsManager extends AllGoodsMenu {
    HashMap<Integer, Good> allGoodsWithId;
    public AllGoodsManager(Menu parentMenu) {
        super(parentMenu);
        this.allGoodsWithId = getGoodsWithNumber();
    }

    @Override
    public void show() {
        allGoodsWithId.clear();
        allGoodsWithId = getGoodsWithNumber();
        System.out.println("--------------------ALL GOODS -------------------------");
        super.show();
        System.out.println("-------------------MANAGE FIELDS -----------------------");
        showManageFieldsForAllGoods();

    }

    @Override
    public void execute() {
        Menu nextMenu=this;
        int startNumberForManaging = getStartInputNumber();
        HashMap<Integer,Good> goodsWithNumber = getGoodsWithNumber();
        int input=Integer.parseInt(inputFormatWithHelpText("\\d+","Enter a number:"));
        if(input==1) {
            nextMenu = parentMenu;
        }else if(input>1 && input<= goodsWithNumber.size()+1){
            Good good = goodsWithNumber.get(input);
            nextMenu = new GoodManager(good,this);
        }else if(input == startNumberForManaging){
            super.show();
            int nextInput = Integer.parseInt(inputFormatWithHelpText("\\d+","Enter a Good number:"));
            if(nextInput>goodsWithNumber.size()+1){
                System.out.println("Invalid Input.");
            }else{
                Good good = goodsWithNumber.get(nextInput);
                nextMenu = new EditGoodsFields(good,this);
            }
        }else if(input == startNumberForManaging+1){
            int nextInput = Integer.parseInt(inputFormatWithHelpText("\\d+","Enter a Good number:"));
            if(nextInput>goodsWithNumber.size()+1){
                System.out.println("Invalid Input.");
            }else{
                Good good = goodsWithNumber.get(nextInput);
                try {
                    goodController.removeGood(good);
                    System.out.println("Confirmed.");
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        }else if(input == startNumberForManaging+2){
            addNewGood();
        }
        nextMenu.show();
        nextMenu.execute();
    }
    private int getStartInputNumber(){
        return  allGoodsWithId.size()+2;
    }
    private void showManageFieldsForAllGoods(){
        int startNumberForManaging = getStartInputNumber();
        System.out.println(startNumberForManaging+"."+"Edit");
        System.out.println((startNumberForManaging+1)+"."+"Remove");
        System.out.println((startNumberForManaging+2)+"."+"Add new Good");

    }
    private void addNewGood(){
        while (true) {
            System.out.println("Write Back to return.");
            System.out.println();
            String goodName = inputFormatWithHelpText(".+", "Good name:");
            if(goodName.equalsIgnoreCase("Back"))
                break;
            String companyName = inputFormatWithHelpText(".+", "company name:");
            if(companyName.equalsIgnoreCase("Back"))
                break;
            String numberOfGoodInString = inputFormatWithHelpText(".+", "numbers Of Goods In Store:");
            int numberOfGoods = Integer.parseInt(numberOfGoodInString);
            if(numberOfGoodInString.equalsIgnoreCase("Back"))
                break;
            String priceInString = inputFormatWithHelpText("\\d+", "price:");
            int price = Integer.parseInt(priceInString);
            if(priceInString.equalsIgnoreCase("Back"))
                break;
            String information = inputFormatWithHelpText(".+", "information:");
            if(information.equalsIgnoreCase("Back"))
                break;
            String categoryName = inputFormatWithHelpText(".+", "category name:");
            if(categoryName.equalsIgnoreCase("Back"))
                break;
            try {
                Category category = goodController.findCategoryByName(categoryName);
                goodController.addGood(goodName, companyName, numberOfGoods, price, category, information);
                System.out.println("Confirmed.");
                break;
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

}
