package views.goodMenu;

import models.GoodsModels.Category;
import models.GoodsModels.Good;
import models.UsersModels.Seller;
import views.Menu;

import java.util.ArrayList;
import java.util.HashMap;

public class GoodManager extends GoodMenu {
    private Good good;
    public GoodManager(Good good, Menu parentMenu) {
        super(good, parentMenu);
        this.good = good;
    }


    @Override
    public void show() {
        showGodInformation();
        System.out.println("1.Back");
        System.out.println("2.Remove");
        System.out.println("3.Edit");

    }

    @Override
    public void execute() {
        Menu nextMenu = this;
        int input = Integer.parseInt(inputFormatWithHelpText("^1|2|3$","Enter a number:").trim());
        if(input == 1){
            nextMenu = parentMenu;
        }else if(input == 2){
            String confirm = inputFormatWithHelpText("^yes$|^no$".trim(),"Type yes to confirm or no to return.");
            if(confirm.equalsIgnoreCase("yes")){
                try {
                    goodController.removeGood(good);
                    System.out.println("Confirm");
                    nextMenu = parentMenu;
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        }else if(input ==3 ){
            nextMenu = new EditGoodsFields(good,this);
        }
        nextMenu.show();
        nextMenu.execute();

    }

}
