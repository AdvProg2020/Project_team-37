package views.goodMenu;

import models.GoodsModels.Category;
import models.GoodsModels.Good;
import models.UsersModels.Seller;
import views.Menu;

import java.util.ArrayList;

public class EditGoodsFields  extends Menu {
    private Good good;
    public EditGoodsFields(Good good, Menu parentMenu) {
        super("Editing", parentMenu);
        this.good = good;
    }
    @Override
    public void show() {
        showGoodsField();
    }

    @Override
    public void execute() {
        Menu nextMenu = this;
        int input = Integer.parseInt(inputFormatWithHelpText("\\d+", "Enter a number:"));
        if (input == 1) {
            nextMenu = parentMenu;
        } else if (input == 2) {
            String newName = inputFormatWithHelpText(".+", "Name:");
            if (!newName.equalsIgnoreCase("1")) {
                try {
                    goodController.changeGoodName(newName, good);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        } else if (input == 3) {
            String companyName = inputFormatWithHelpText(".+", "companyName:");
            if (!companyName.equalsIgnoreCase("1")) {
                try {
                    goodController.changeCompanyNameOfGood(companyName, good);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }

        } else if (input == 4) {

            String newPrice = inputFormatWithHelpText("\\d+", "price:");
            if (!newPrice.equalsIgnoreCase("1")) {
                try {
                    goodController.changePriceOfGood(newPrice, good);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        } else if (input == 5) {

            String categoryName = inputFormatWithHelpText(".+", "category:");
            if (!categoryName.equalsIgnoreCase("1")) {
                try {
                    Category category = goodController.findCategoryByName(categoryName);
                    goodController.changeGoodCategory(category, good);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        } else if (input == 6) {

            String information = inputFormatWithHelpText(".+", "information:");
            if (!information.equalsIgnoreCase("1")) {
                try {
                    goodController.changeInformationForGood(information, good);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        } else if (input == 7) {
            String numberOfGoodsInStore = inputFormatWithHelpText(".+", "numbers of goods In Store: | write back to return");
            if (!numberOfGoodsInStore.equalsIgnoreCase("back")) {
                try {
                    int goodsNumber = Integer.parseInt(numberOfGoodsInStore);
                    goodController.changeNumberOfThisGoodInTheStore(goodsNumber, good);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }

        } else if (input == 8) {
            nextMenu = new Menu("", this) {
                @Override
                public void show() {
                    System.out.println("1.Back");
                    System.out.println("------------------------ALL SELLERS---------------------------------------");
                    showSellers();
                    System.out.println("2.Add seller");
                    System.out.println("3.Remove Seller");
                }

                @Override
                public void execute() {
                    Menu nextMenu = this;
                    int input = Integer.parseInt(inputFormatWithHelpText("^1|2|3$", "Enter a number"));
                    if (input == 1) {
                        nextMenu = parentMenu;
                    } else if (input == 2) {
                        String sellerUserName = inputFormatWithHelpText(".+", "Seller username:");
                        try {
                            goodController.addSellerToGood(sellerUserName, good);
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                    } else if (input == 3) {
                        String sellerUserName = inputFormatWithHelpText(".+", "Seller username:");
                        try {
                            goodController.removeSellerFromGood(sellerUserName, good);
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    nextMenu.show();
                    nextMenu.execute();
                }
            };
        }
        nextMenu.show();
        nextMenu.execute();
    }
    private void showGoodsField () {
            System.out.println("1.Back");
            System.out.println("2.name");
            System.out.println("3.companyName");
            System.out.println("4.price");
            System.out.println("5.category");
            System.out.println("6.information");
            System.out.println("7.numbersOfGoodsInStore");
            System.out.println("8.sellers");
        }
    private void showSellers() {
        ArrayList<Seller> sellers = good.getSellers();
        if (!sellers.isEmpty()) {
            for (Seller seller : sellers) {
                System.out.println("User Name : " + seller.getUserName());
                System.out.println("first name : " + seller.getFirstName());
                System.out.println("last name : " + seller.getLastName());
                System.out.println("telephone number : " + seller.getTelephoneNumber());
                System.out.println("email address : " + seller.getEmailAddress());
                System.out.println("---------------------------------------------------------------------");
            }
        }else{
            System.out.println("There is no seller yet!");
        }
    }
    }
