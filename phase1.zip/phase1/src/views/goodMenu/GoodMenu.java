package views.goodMenu;

import models.GoodsModels.Comment;
import models.GoodsModels.Good;
import models.UsersModels.Customer;
import models.UsersModels.Seller;
import views.MainMenu;
import views.Menu;
import views.userMenu.LoginMenu;

import java.util.ArrayList;

public class GoodMenu extends Menu {
    private Good good;
    public GoodMenu(Good good, Menu parentMenu) {
        super(good.getName(), parentMenu);
        this.good = good;
    }

    @Override
    public void show() {
        showGodInformation();
        System.out.println("----------------------------------------------------------------------------");
        System.out.println("1.Back");
        System.out.println("2.Add to the cart");
        System.out.println("3.Add comment");
        System.out.println("4.Rate");
        System.out.println("5.See all comments");
    }

    @Override
    public void execute() {
        Menu nextMenu = this;
        int input = Integer.parseInt(inputFormatWithHelpText("^1|2|3|4|5$","Enter a number:"));
        if(input == 1){
            nextMenu = parentMenu;
        }else if(input ==2 ){
            if(MainMenu.getAccount() == null){
                nextMenu = new LoginMenu(this);

            }else{
                int goodsNumber = Integer.parseInt(inputFormatWithHelpText("\\d+","how many of this item you want to add?"));
                Customer customer = (Customer) MainMenu.getAccount();//this should change to account later.
                try {
                    userController.addItemToCart(customer,good,goodsNumber);
                    System.out.println("Item has been added successfully.");
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        }else if(input == 3){
            if(MainMenu.getAccount() == null){
                nextMenu = new LoginMenu(this);
            }else{
                Customer customer =(Customer) MainMenu.getAccount();
                String comment = inputFormatWithHelpText(".+" , "Please type your comment. or write back to return");
                if(!comment.equalsIgnoreCase("back")) {
                    goodController.addComment(customer, good, comment);
                    System.out.println("Comment has added successfully.");
                }
            }
        }else if(input == 4) {
            if(MainMenu.getAccount() == null){
                nextMenu = new LoginMenu(this);
            }else{
                Customer customer = (Customer) MainMenu.getAccount();
                double rate = Double.parseDouble(inputFormatWithHelpText("\\d+" ,
                        "Please enter a number between  0 to 5"));
                if(rate < 0  || rate > 5)
                    System.out.println("Invalid number!");
                else{
                    try {
                        goodController.addRate(customer,rate,good);
                        System.out.println("Thanks for you rate.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                }
            }
        }else if(input == 5){
            ArrayList<Comment> comments = goodController.getAllCommentForGood(good);
            if(comments.isEmpty())
                System.out.println("There is no comment for this good yet!");
            else{
                for (Comment comment : comments) {
                    System.out.println(comment.getCustomer().getUserName() + " : " + comment.getCommentText());
                    System.out.println("-------------------------------------");
                }
            }
        }
        if(nextMenu!=this)
        nextMenu.show();
        nextMenu.execute();

    }

    protected void showGodInformation(){
        System.out.println(good.getName()+":");
        showAvailability();
        System.out.println("Company : " + good.getCompanyName());
        System.out.println("Category" + good.getCategory());
        System.out.println("Information : " + good.getInformation());
        System.out.println("Number of "+good.getCompanyName() + " in the store: " + good.getNumbersOfGoodsInStore());
        System.out.println("Price : "+good.getPrice());
        System.out.print("Sellers:" );
        showSellersForThisGood();
        System.out.println("current Rate : " + good.getAverageRate());



    }
    protected void showSellersForThisGood(){
        ArrayList<Seller> sellers = goodController.getSellerForGood(good);
        for (Seller seller : sellers) {
            System.out.print(seller+",");
        }

    }
    protected void showAvailability(){
        if(good.isAvailable())
            System.out.println(good.getName() + "is available.");
        else
            System.out.println(good.getName() + "is not available at the moment.");
    }

}
