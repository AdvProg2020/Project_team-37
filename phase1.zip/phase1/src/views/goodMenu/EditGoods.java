package views.goodMenu;

import views.Menu;

public class EditGoods extends Menu {
    public EditGoods( Menu parentMenu) {
        super("Editing Goods", parentMenu);
    }
}
