package views;

import models.UsersModels.Account;
import models.UsersModels.AccountType;
import models.UsersModels.Customer;
import models.UsersModels.Manager;
import views.goodMenu.GoodsMenu;
import views.saleMenus.SaleMenu;
import views.userMenu.AccountsMenu;
import views.userMenu.CustomerAccount;
import views.userMenu.ManagerAccount;

public class MainMenu extends Menu {
    private static Account account=null;
    private static AccountType accountType = null;
    public MainMenu() {
        super("Main menu", null);

    }

    public static Account getAccount() {
        return account;
    }

    public static void setAccount(Account account) {
        MainMenu.account = account;
    }

    private void setSubMenus(){
        if(account==null) {
            subMenus.put(1, new AccountsMenu(this));
        }else{
            if(accountType.equals(AccountType.CUSTOMER))
                subMenus.put(1,new CustomerAccount((Customer) account,this));
            else if(accountType.equals(AccountType.MANAGER))
                subMenus.put(1,new ManagerAccount((Manager)account,this));
        }
        subMenus.put(2, new SaleMenu(this));
        subMenus.put(3, new GoodsMenu(this));
    }

    @Override
    public void show() {
        accountType = getAccountType();
        subMenus.clear();
        setSubMenus();
        super.show();
    }

    @Override
    public void execute() {
        subMenus.clear();
        setSubMenus();
        super.execute();
    }

    private AccountType getAccountType(){
        if(account == null)
            return null;
        else{
            return account.getAccountType();
        }
    }
}


