package views.saleMenus;

import models.GoodsModels.Good;
import models.Sales.Sale;
import models.Sales.SaleStatus;
import models.UsersModels.Account;
import models.UsersModels.AccountType;
import models.UsersModels.Manager;
import models.UsersModels.Seller;
import views.Menu;

import javax.jnlp.IntegrationService;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

public class EditSale extends Menu{

private HashMap<Integer,Sale> allSale;
AccountType accountType ;
Account currentAccount;
    public EditSale(Menu parentMenu, Account account) {
        super("Sales Manager", parentMenu);
        this.currentAccount = account;
        this.accountType = account.getAccountType();
        try {
            int startNumberForSale = getStartNumberForSale();
            this.allSale = saleController.getAllSaleWithId(startNumberForSale);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }


    }

    @Override
    public void show() {
        System.out.println("1.Back");
        System.out.println("2.Add new sale");
        System.out.println("------------------------ALL SALES ------------------------------------------");
        try {
            showAllSales();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    @Override
    public void execute() {
       Menu nextMenu = this;
       int input = Integer.parseInt(inputFormatWithHelpText("\\d+","Enter a number or chose a sale to edit:"));
       if(input == 1) {
           nextMenu = parentMenu;
       }else if(input == 2){
           if(accountType.equals(AccountType.SELLER)){
               try {
                   addRequestForNewSale();
               } catch (Exception e) {
                   System.out.println(e.getMessage());
               }
           }else if(accountType.equals(AccountType.MANAGER)){
               try {
                   addSaleToDataBase();
               } catch (Exception e) {
                   System.out.println(e.getMessage());
               }
           }
       }else if(input >= 3 && input <= allSale.size()+4){
        Sale sale = allSale.get(input);
        nextMenu = new Menu("Editing Sale",this) {
            @Override
            public void show() {
                showFieldsForEdit();
            }

            @Override
            public void execute() {
                Menu nextMenu = this;
                int input = Integer.parseInt(inputFormatWithHelpText("1|2|3|4|5|6|7","Enter a number"));
                if(input == 1){
                    showGoods(sale.getGoods());
                    System.out.println("---------------------------------------");
                    ArrayList<Good> goods = getGoodsWithName();
                    if(accountType.equals(AccountType.SELLER)){
                        sale.getGoods().clear();
                        sale.getGoods().addAll(goods);
                        saleController.addRequestForEditingSale((Seller) currentAccount, sale);
                    }else if(accountType.equals(AccountType.MANAGER)){
                        try {
                            saleController.replaceSalesGoods(goods,sale);
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                    }
                }else if(input == 2){//for editing the end date of the sale
                    String endDate = inputFormatWithHelpText("^\\d{4}-\\d{1,12}-\\d{1,31}\\s+T\\d{0,23}:\\d{0,59}$",
                            "Enter end date and time of the sale like this 2018-3-24 T6:30");
                    if(accountType.equals(AccountType.SELLER)){
                        LocalDateTime endDateLocalDate = LocalDateTime.parse(endDate);
                       sale.setEndDate(endDateLocalDate);
                       saleController.addRequestForEditingSale((Seller)currentAccount,sale);
                    }else if(accountType.equals(AccountType.MANAGER)){
                        try {
                            saleController.setNewEndDateForSale(endDate,sale);
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                    }
                }else if(input == 3){//for editing the start date of the sale
                    String startDate = inputFormatWithHelpText("^\\d{4}-\\d{1,12}-\\d{1,31}\\s+T\\d{0,23}:\\d{0,59}$",
                            "Enter start date and time of the sale like this 2018-3-24 T6:30");
                    if(accountType.equals(AccountType.SELLER)){
                        LocalDateTime startDateLocalDate = LocalDateTime.parse(startDate);
                        sale.setStartDate(startDateLocalDate);
                        saleController.addRequestForEditingSale((Seller)currentAccount,sale);
                    }else if(accountType.equals(AccountType.MANAGER)){
                        try {
                            saleController.setNewStartDateForSale(startDate,sale);
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                    }
                }else if(input == 4){//for editing sale amount of the sale
                    if(accountType.equals(AccountType.SELLER)){
                        int saleAmount = Integer.parseInt(inputFormatWithHelpText("\\d+","Enter a number:"));
                        sale.setSaleAmount(saleAmount);
                        saleController.addRequestForEditingSale((Seller) currentAccount,sale);
                    }else if(accountType.equals(AccountType.MANAGER)){
                        int saleAmount = Integer.parseInt(inputFormatWithHelpText("\\d+","Enter a number:"));
                        try {
                            saleController.changeSaleAmount(saleAmount,sale);
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                    }
                }else if(input == 5){//for editing the sale status of the sale
                    if(accountType.equals(AccountType.SELLER)){
                        nextMenu = parentMenu;
                    }else if(accountType.equals(AccountType.MANAGER)){
                        System.out.println("1.Back");
                        System.out.println("2.Set Status Waiting to make");
                        System.out.println("3.Set Status Waiting to edit");
                        System.out.println("4.Set Status Confirmed");
                        int nextInput = Integer.parseInt(inputFormatWithHelpText("1|2|3|4","Enter a number:"));
                        if(nextInput == 2){
                            try {
                                saleController.changeSaleStatus(SaleStatus.WAITING_TO_MAKE,sale);
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        }else if(nextInput == 3){
                            try {
                                saleController.changeSaleStatus(SaleStatus.WAITING_FOR_EDIT,sale);
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        }else if(nextInput == 4){
                            try {
                                saleController.changeSaleStatus(SaleStatus.CONFIRMED,sale);
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        }

                    }
                }else if(input == 6){//for removing sale if account is manager  type
                    if(accountType.equals(AccountType.SELLER)){
                        System.out.println("Invalid input");
                    }else if(accountType.equals(AccountType.MANAGER)){
                        try {
                            saleController.removeSale(sale);
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                    }
                }else if(input == 7){
                    if(accountType.equals(AccountType.SELLER)){
                        System.out.println("Invalid input");
                    }else if(accountType.equals(AccountType.MANAGER)){
                        nextMenu = parentMenu;
                    }
                }

            }
        };
       }

       nextMenu.show();
       nextMenu.execute();
    }
    private void showAllSales() throws Exception {
        if(allSale.isEmpty()){
            throw new Exception("There is no sales yet.");
        }
        for (Integer integer : allSale.keySet()) {
            Sale sale = allSale.get(integer);
            System.out.println(integer+".");
            System.out.println("Start date : " + sale.getStartDate());
            System.out.println("End date : " + sale.getEndDate());
            System.out.println("Sale Price : " + sale.getSaleAmount());
            System.out.println("Goods in this sale:");
            showGoodsInSale(sale,1);
            System.out.println("-----------------------------------------");
        }
    }
    private void showGoodsInSale(Sale sale,int startNumber){
        HashMap<Integer,Good> goodsInSale = getGoodsInSale(sale,startNumber);
        for (Integer integer : goodsInSale.keySet()) {
            System.out.println(integer+"."+goodsInSale.get(integer).getName());
        }
    }
    private HashMap<Integer,Good> getGoodsInSale(Sale sale,int startNumber){
        ArrayList<Good> goods = sale.getGoods();
        HashMap<Integer,Good> goodsWithId = new HashMap<>();
        int str = startNumber;
        for (Good good : goods) {
            goodsWithId.put(startNumber , good);
            str ++;
        }
       return goodsWithId;
    }
    private Sale makeNewSale(){
        while (true) {
            ArrayList<Good> goods = getGoodsWithName();
            if(goods.isEmpty())
                break;
            System.out.println("Write Back to return or fill the blanks.");
            String saleAmountInString =inputFormatWithHelpText("^(\\d+)|(back)$", "Sale Amount : ");
            if(saleAmountInString.equalsIgnoreCase("back"))
                break;
            else {
                int saleAmount = Integer.parseInt(saleAmountInString);
                String startDate = inputFormatWithHelpText("^(\\d{4}-\\d{1,12}-\\d{1,31}\\s+T\\d{0,23}:\\d{0,59})|(back)$",
                        "Enter start date and time of the sale like this 2018-3-24 T6:30");
                if(startDate.equalsIgnoreCase("Back"))
                    break;
                String endDate = inputFormatWithHelpText("^(\\d{4}-\\d{1,12}-\\d{1,31}\\s+T\\d{0,23}:\\d{0,59})|(back)$",
                        "Enter End date and time of the sale like this 2018-5-31 T16:30");
                if(endDate.equalsIgnoreCase("back"))
                    break;
                return new Sale(goods, saleAmount, SaleStatus.WAITING_TO_MAKE, startDate, endDate);
            }
        }
        return null;
    }
    private ArrayList<Good> getGoodsWithName(){
        ArrayList<Good> goods = new ArrayList<>();
        while (true){
            showGoods(goods);
            String goodName = inputFormatWithHelpText(".+","Enter goods name you want to add:  | write stop to return");
            if(goodName.equalsIgnoreCase("stop"))
                break;
            else {
                Good good = null;
                try {
                    good = goodController.findGoodByName(goodName);
                    goods.add(good);
                    System.out.println("good added successfully");
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        }
        return goods;
    }

    private void showGoods(ArrayList<Good> goods){
        int i=1;
        for (Good good : goods) {
            System.out.println(i+"."+good.getName());
            i++;
        }
    }
    private void addRequestForNewSale() throws Exception {
        Sale sale = makeNewSale();
        if(saleController.checkSale(sale))
            saleController.addRequestForNewSale((Seller)currentAccount,sale);
        else
            throw new Exception("This sale has already exist.");
    }
    private void addSaleToDataBase() throws Exception {
        Sale newSale = makeNewSale();
        if(saleController.checkSale(newSale)){
            saleController.addSale(newSale);
        }else{
            throw new Exception("This sale has already exist.");
        }

    }
    private int getStartNumberForSale() throws Exception{
        if(accountType.equals(AccountType.SELLER)){
            return 3;
        }else if(accountType.equals(AccountType.MANAGER))
            return 4;
        else throw new Exception("Something went wrong please try again");
    }
    private void showFieldsForEdit(){
        if(accountType.equals(AccountType.MANAGER)){
            System.out.println("EDITING SALE\n");
            System.out.println("1.Edit Goods");
            System.out.println("2.Edit end Date");
            System.out.println("3.Edit start Date");
            System.out.println("4.Change Sale Amount");
            System.out.println("5.Change sale status");
            System.out.println("6.Remove");
            System.out.println("7.Back");
        }else{
            System.out.println("SEND REQUEST FOR EDITING SALE\n");
            System.out.println("1.Edit Goods");
            System.out.println("2.Edit end Date");
            System.out.println("3.Edit start Date");
            System.out.println("4.Change Sale Amount");
            System.out.println("5.Back");
        }
    }


}
