package views.saleMenus;

import views.Menu;

public class EditDiscounts extends Menu {
    public EditDiscounts( Menu parentMenu) {
        super("Editing Discounts", parentMenu);
    }
}
