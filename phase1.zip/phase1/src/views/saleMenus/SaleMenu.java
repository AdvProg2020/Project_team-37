package views.saleMenus;

import models.GoodsModels.Good;
import models.Sales.Sale;
import views.Menu;
import views.goodMenu.GoodMenu;

import java.util.HashMap;

public class SaleMenu extends Menu {
    private HashMap<Integer, Good> goodsWithSale;
    public SaleMenu( Menu parentMenu) {
        super("Sales page", parentMenu);
        try {
            this.goodsWithSale =  saleController.getGoodsWithSaleById();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    @Override
    public void show() {
        System.out.println("1.Back");
        try {
            showAllGoodsWithSales();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    @Override
    public void execute() {
       Menu nextMenu = this;
       int input = Integer.parseInt(inputFormatWithHelpText("\\d+","Enter a number:"));
       if(input == 1){
           nextMenu = parentMenu;
       }else if(input > 1 && input <= goodsWithSale.size()+1){
           Good good = goodsWithSale.get(input);
           nextMenu = new GoodMenu(good,this);
       }else{
           System.out.println("Invalid Command!");
       }
       nextMenu.show();
       nextMenu.execute();
    }
    protected void showAllGoodsWithSales() throws Exception{
        if(!goodsWithSale.isEmpty()) {
            for (Integer integer : goodsWithSale.keySet()) {
                Good good = goodsWithSale.get(integer);
                Sale sale = saleController.getSaleByGood(good);
                System.out.print(integer + ". " + good.getName() + "\n" + "Old Price : " + good.getPrice() + "\n New Price : " + good.getPrice() +
                        " \nSale Amount : " + sale.getSaleAmount() + "%  \nStart Data : " + sale.getStartDate() +
                        " \nEnd Date :" + sale.getEndDate() + "\nSale Status : " + sale.getSaleStatus());
                System.out.println("\n--------------------------------------------------------------------------");
            }
        }else{
            throw new Exception("There is no sale yet!");
        }
    }


}
