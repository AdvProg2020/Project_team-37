package views.userMenu;

import models.UsersModels.AccountType;
import models.UsersModels.Customer;
import views.Menu;

import java.util.HashMap;

public class ManageAllCustomers extends Menu {
    HashMap<Integer, Customer> allCustomerWithId;
    public ManageAllCustomers( Menu parentMenu) {
        super("All customers manager" ,parentMenu);
        this.allCustomerWithId = userController.getAllCustomersWithId();
    }

    @Override
    public void show() {
        int startNumberForManaging = getStartInputNumberForManaging();
        this.allCustomerWithId = userController.getAllCustomersWithId();
        System.out.println("For changing customer account type or deleting them chose a customer.");
        System.out.println("1.Back");
        showAllCustomersWithId();
        System.out.println(startNumberForManaging+".Add new Customer");
    }

    @Override
    public void execute() {
        int startNumberForManaging = getStartInputNumberForManaging();
        Menu nextMenu = this;
        int input = Integer.parseInt(inputFormatWithHelpText("\\d+","Enter a number:"));
        if(input == 1){
            nextMenu = parentMenu;
        }else if(input >1 && input <=allCustomerWithId.size()+1){
            Customer customer = allCustomerWithId.get(input);
            nextMenu = new Menu("",this) {
                @Override
                public void show() {
                    System.out.println("1.Back");
                    System.out.println("2.Change Account type");
                    System.out.println("3.Remove");
                }

                @Override
                public void execute() {
                    Menu nextMenu = this;
                    int input = Integer.parseInt(inputFormatWithHelpText("^1|2|3$","Enter a number:"));
                    if(input == 1){
                        nextMenu = parentMenu;
                    }else if(input == 2){
                        changeCustomerAccountType(customer);
                    }else if(input == 3){
                        String confirm = inputFormatWithHelpText("^(?i)(yes|no)$","Are you sure ? (Answer with yes or no)");
                        if(confirm.equalsIgnoreCase("yes")){
                           userController.removeCustomer(customer);
                            System.out.println("Account has removed successfully");
                        }
                    }
                    nextMenu.show();
                    nextMenu.execute();
                }
            };
        }else if(input == startNumberForManaging){
            SignUpMenu signUpMenu = new SignUpMenu(this);
            try {
                signUpMenu.signUp(AccountType.CUSTOMER);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            System.out.println("Invalid input!");
        }

        nextMenu.show();
        nextMenu.execute();
    }
    private void showAllCustomersWithId(){
        for (Integer integer : allCustomerWithId.keySet()) {
            Customer customer = allCustomerWithId.get(integer);
            System.out.println(integer +".");
            CustomerAccount.showAccountInformation(customer);
        }
    }
    private int getStartInputNumberForManaging(){
        return allCustomerWithId.size()+2;
    }
    private void changeCustomerAccountType(Customer customer){
        System.out.println("1.Back");
        System.out.println("2.Change to seller");
        System.out.println("3.Change to manager");
        int input = Integer.parseInt(inputFormatWithHelpText("^1|2|3$","Enter a number:"));
        if(input == 2){
            String companyName = inputFormatWithHelpText(".+","Company name:");
            String confirm = inputFormatWithHelpText("^(?i)(yes|no)$","Are you sure ? (Answer with yes or no)");
            if(confirm.equalsIgnoreCase("yes")){
                userController.changeCustomerAccountToSeller(customer,companyName);
                System.out.println("Account has changed successfully");
            }
        }else if(input == 3){
            String confirm = inputFormatWithHelpText("^(?i)(yes|no)$","Are you sure ? (Answer with yes or no)");
            if(confirm.equalsIgnoreCase("yes")){
                userController.changeCustomerAccountToManager(customer);
                System.out.println("Account has changed successfully");
            }
        }
    }
}
