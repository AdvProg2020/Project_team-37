package views.userMenu;

import views.Menu;

public class ManageAllSellers extends Menu {
    public ManageAllSellers( Menu parentMenu) {
        super("All Sellers manager", parentMenu);
    }
}
