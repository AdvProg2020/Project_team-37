package views.userMenu;

import models.UsersModels.Manager;
import views.MainMenu;
import views.Menu;
import views.goodMenu.CategoriesManager;
import views.goodMenu.AllGoodsManager;

public class ManagerAccount extends Menu {
    private Manager manager ;
    public ManagerAccount(Manager manager, Menu parentMenu) {
        super("Your Account",parentMenu);
        this.manager = manager;
    }

    @Override
    public void show() {
        showMenu();
    }

    @Override
    public void execute() {
        Menu nextMenu = this;
        int input = Integer.parseInt(inputFormatWithHelpText("^1|2|3|4|5|6|7|8|9$", "Enter a number:"));
        if (input == 1) {
            CustomerAccount.showAccountInformation(manager);
        } else if (input == 2) {
            nextMenu = new ChangeInformation(this,manager);
        } else if (input == 3) {
            nextMenu = new ManageAllUsers(this);
        } else if (input == 4) {
            nextMenu = new AllGoodsManager(this);
        } else if (input == 5) {

        } else if (input == 6) {

        } else if (input == 7) {
            nextMenu = new CategoriesManager(null,this);
        }else if (input == 8) {
            nextMenu = parentMenu.getParentMenu();
        } else if (input == 9) {
            MainMenu.setAccount(null);
            nextMenu = parentMenu;
        }
        nextMenu.show();
        nextMenu.execute();
    }


    private void showMenu(){
        System.out.println("1.Account information");
        System.out.println("2.Change Information");
        System.out.println("3.Manage users");//not done
        System.out.println("4.Manage all products");
        System.out.println("5.Manage discount codes");//not done
        System.out.println("6.Manage Requests");//not done
        System.out.println("7.Manage categories");
        System.out.println("8.Back");
        System.out.println("9.Log out");
    }



}
