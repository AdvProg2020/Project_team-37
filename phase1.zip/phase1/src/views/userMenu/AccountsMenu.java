package views.userMenu;
import models.UsersModels.Account;
import views.Menu;


public class AccountsMenu extends Menu {

    public AccountsMenu(Menu parentMenu) {
        super("User Menu", parentMenu);
        subMenus.put(1, new SignUpMenu(this));
        subMenus.put(2, new LoginMenu(this));
    }

}




