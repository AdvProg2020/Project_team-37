package views.userMenu;

import models.GoodsModels.Good;
import models.Logs.ShoppingCart;
import models.Logs.ShoppingLog;
import models.UsersModels.Account;
import models.UsersModels.Customer;
import views.MainMenu;
import views.Menu;

import java.util.ArrayList;
import java.util.HashMap;

public class CustomerAccount extends Menu {
    private static Customer currentUser;
    public CustomerAccount( Customer customer,Menu parentMenu) {
        super("You Account", parentMenu);
        this.currentUser = customer;

    }

    @Override
    public void show() {
        showMenu();
    }

    @Override
    public void execute() {
        Menu nextMenu=this;
        int input=Integer.parseInt(inputFormat("^1|2|3|4|5|6|7$").trim());
        if(input == 1) {
            showAccountInformation(currentUser);
        }else if(input == 2){
            nextMenu = new ChangeInformation(this,currentUser);
        }else if(input == 3){
          nextMenu = new Menu("Credit",this) {
              @Override
              public void show() {
                  System.out.println("your credit right now is : "+currentUser.getCredit());
                  System.out.println("1.Add Credit");
                  System.out.println("2.Back");
              }

              @Override
              public void execute() {
                  Menu nextMenu = this;
                  int input = Integer.parseInt(inputFormat("^1|2$"));
                  if(input == 1){
                      currentUser.setCredit(Double.parseDouble(inputFormatWithHelpText("\\d+","how much money do you want to add?")));
                  }else{
                      nextMenu = parentMenu;
                  }
                  nextMenu.show();
                  nextMenu.execute();
              }
          };
        }else if(input == 4){
            try {
                showShoppingHistory();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }else if(input == 5){
        nextMenu = new ShoppingCartMenu(currentUser,this);

        }else if(input == 6){
            nextMenu = parentMenu.getParentMenu();

        }else if(input == 7){
            MainMenu.setAccount(null);
            nextMenu= parentMenu;
        }
        nextMenu.show();
        nextMenu.execute();

    }
    private void showMenu(){
        System.out.println("1.Account information");
        System.out.println("2.Change Information");
        System.out.println("3.Credit");
        System.out.println("4.Shopping histories");
        System.out.println("5.Shopping cart");
        System.out.println("6.Return to main menu");
        System.out.println("7.Logout");
    }
    public static void showAccountInformation(Account account){
        System.out.println("---------------------------");
        System.out.println();
        System.out.println("User name: "+ account.getUserName());
        System.out.println("First name: "+ account.getFirstName());
        System.out.println("Last name: "+ account.getLastName());
        System.out.println("Email address: "+ account.getEmailAddress());
        System.out.println("Telephone number: "+ account.getTelephoneNumber());
        System.out.println("---------------------------");
        System.out.println();

    }

    private  void showShoppingHistory()throws Exception{
        ArrayList<ShoppingLog> shoppingHistories = currentUser.getShoppingHistories();
        if(shoppingHistories.isEmpty()){
            throw new Exception("You having buy anything for this store yet!");
        }
        for (ShoppingLog shoppingHistory : shoppingHistories) {
            int i=1;
            HashMap<Good,Integer> goods = shoppingHistory.getGoodsList();
            System.out.println("---------------------------------------------");
            System.out.println("Shopping id:"+ shoppingHistory.getShoppingLogId());
            System.out.println("Shopping Date:" + shoppingHistory.getDate());
            System.out.println("Delivery status:"+shoppingHistory.getDeliveryStatus());
            System.out.print("+-----------------+------------+------------+\n");
            System.out.print("| Good name       | Number  | Price(IRR) |\n");
            System.out.print("+-----------------+------------+------------+\n");
            for (Good good : goods.keySet()) {
                System.out.format("| %-15s | %-5d item | %-10d |%n", good.getName(), goods.get(good), good.getPrice() * goods.get(good));
            }
            System.out.println("+-----------------+------------+------------+");
            System.out.println("Paid Amount : "+ shoppingHistory.getPaidAmount());
            System.out.println("Discount : "+ shoppingHistory.getDiscountAmount());
            System.out.println("Seller : " + shoppingHistory.getSeller().getTelephoneNumber());
            System.out.println("---------------------------------------------");
            System.out.println();
        }
    }


}
