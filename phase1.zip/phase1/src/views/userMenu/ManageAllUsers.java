package views.userMenu;

import models.GoodsModels.Category;
import models.UsersModels.AccountType;
import views.Menu;

public class ManageAllUsers extends Menu {
    public ManageAllUsers( Menu parentMenu) {
        super("Manage all users", parentMenu);
    }

    @Override
    public void show() {
        showManageAllUsersFields();
    }

    @Override
    public void execute() {
        Menu nextMenu = this;
        int input = Integer.parseInt(inputFormatWithHelpText("^1|2|3|4$","Enter a number:"));
        if(input == 1 ){
            nextMenu = parentMenu;
        }else if(input == 2){
            nextMenu = new ManageAllCustomers(this);
        }else if(input == 3){
            nextMenu = new ManageAllSellers(this);
        }else if(input == 4){
            addManager();
        }
        nextMenu.show();
        nextMenu.execute();
    }
    private void showManageAllUsersFields(){
        System.out.println("1.Back");
        System.out.println("2.Manage Customers");
        System.out.println("3.Manage sellers");
        System.out.println("4.Add a new Manager");
    }
    private void addManager() {
        SignUpMenu signUpMenu = new SignUpMenu(this);
        try {
            signUpMenu.signUp(AccountType.MANAGER);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
