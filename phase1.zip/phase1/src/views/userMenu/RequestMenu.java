package views.userMenu;

import models.UsersModels.Seller;
import views.MainMenu;
import views.Menu;
import views.goodMenu.EditGoods;
import views.saleMenus.EditDiscounts;
import views.saleMenus.EditSale;


public class RequestMenu extends Menu {
    public RequestMenu( Menu parentMenu) {
        super("Request Menu", parentMenu);
    }

    @Override
    public void show() {
        showRequestFields();
    }

    @Override
    public void execute() {
        Menu nextMenu = this;
        int input = Integer.parseInt(inputFormatWithHelpText("^1|2|3|4$","Enter a number:"));
        if(input == 1){
            nextMenu = parentMenu;
        }else if(input == 2){
           nextMenu =new EditGoods(this);
        }else if(input == 3){
            nextMenu =new EditDiscounts(this);
        }else if(input == 4){
            nextMenu = new EditSale(this, MainMenu.getAccount());
        }
        nextMenu.show();
        nextMenu.execute();
    }
    private void showRequestFields(){
        System.out.println("1.Back");
        System.out.println("2.Add Goods requests");
        System.out.println("3.Add Discount requests");
        System.out.println("4.Add Sale requests");
    }


}
