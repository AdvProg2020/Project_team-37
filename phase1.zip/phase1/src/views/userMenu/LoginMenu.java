package views.userMenu;

import models.UsersModels.*;
import views.MainMenu;
import views.Menu;

public class LoginMenu extends Menu {
    private String userName;
    private String password;

    public LoginMenu(Menu parentMenu) {
        super("Login", parentMenu);
    }

    @Override
    public void show() {
        System.out.println("Please fill the blanks or write back to return.");
    }

    @Override
    public void execute() {
        Menu nextMenu = null;
            while (true) {
                userName = inputFormatWithHelpText(".+", "User name:");
                if (userName.equalsIgnoreCase("back")) {
                    nextMenu = parentMenu;
                    break;
                }
                password = inputFormatWithHelpText(".+", "Password");
                if (userName.equalsIgnoreCase("back")) {
                    nextMenu = parentMenu;
                    break;
                }
                try {
                    if (userController.loginProcess(userName, password)) {
                        Account account=userController.findAccountByUserName(userName);
                        userController.login(account);
                        MainMenu.setAccount(account);
                        if(account.getAccountType().equals(AccountType.CUSTOMER))
                        nextMenu=new CustomerAccount((Customer) account,this.parentMenu);
                        else if(account.getAccountType().equals(AccountType.MANAGER)){
                            nextMenu = new ManagerAccount((Manager) account , this.parentMenu);
                        }else if(account.getAccountType().equals(AccountType.SELLER)){
                            nextMenu = new SellerAccount((Seller) account,this.parentMenu);
                        }
                        break;
                    }
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        nextMenu.show();
        nextMenu.execute();
    }

    }



