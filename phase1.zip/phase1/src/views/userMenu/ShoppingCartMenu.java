package views.userMenu;

import models.GoodsModels.Good;
import models.Logs.ShoppingCart;
import models.UsersModels.Customer;
import views.Menu;

import java.util.HashMap;

public class ShoppingCartMenu extends Menu {
    private ShoppingCart shoppingCart;
    private HashMap<Integer,Good> shoppingCartWithID;
    private HashMap<Good, Integer> goodsInCart ;
    private Customer currentCustomer;

    public ShoppingCartMenu(Customer customer, Menu parentMenu) {
        super("Shopping cart", parentMenu);
        this.currentCustomer = customer;
        this.shoppingCart = customer.getShoppingCart();
        this.shoppingCartWithID = userController.getShoppingCartWithID(customer);
        this.goodsInCart = shoppingCart.getGoodInCart();
    }

    @Override
    public void show() {
        System.out.println("1.Back");
        showCart();

    }

    @Override
    public void execute() {
        Menu nextMenu= this;
        int input = Integer.parseInt(inputFormat("\\d+"));
        if(input==1){
            nextMenu = parentMenu;
        }else if(input>1 && input < shoppingCartWithID.size()+1){
            Good good = shoppingCartWithID.get(input);
            nextMenu = new Menu("good.getName()",this) {
                @Override
                public void show() {
                    System.out.println("1.Back");
                    System.out.println("2.Add more Item");
                    System.out.println("3.Remove Item");
                }

                @Override
                public void execute() {
                    Menu nextMenu = this;
                    int goodAmountInCart = currentCustomer.getShoppingCart().getGoodInCart().get(good);
                    int input = Integer.parseInt(inputFormatWithHelpText("^1|2|3$","Enter a number"));
                    if(input==1){
                        nextMenu = parentMenu;
                    }else if(input ==2){
                        int numberToAdd = Integer.parseInt(inputFormatWithHelpText("\\d+","How many items do you want to add?"));
                        try {
                            userController.addItemToCart(currentCustomer,good,numberToAdd+goodAmountInCart);
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }

                    }else if(input == 3){
                        int numberToRemove = Integer.parseInt(inputFormatWithHelpText("\\d+","How many items do you want to remove?"));
                        try {
                            userController.removeItemFromCart(currentCustomer,good,goodAmountInCart - numberToRemove);
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    nextMenu.show();
                    nextMenu.execute();
                }
            };
        }else if(input<0){
            System.out.println("Invalid Number!");
        }
        nextMenu.show();
        nextMenu.execute();
    }
    private void showCart(){
        if(shoppingCartWithID.isEmpty()) {
            System.out.println("There is no item here yet.");
            return;
        }
        for (Integer ID : shoppingCartWithID.keySet()) {
            Good good = shoppingCartWithID.get(ID);
            double price = good.getPrice() * goodsInCart.get(good);
            System.out.println(ID+"-"+ good.getName() + " Amount: ");
            showItemInShoppingCart();
            System.out.println(" price:"+price);
        }
    }
    private void showItemInShoppingCart(){
        for (Good good : shoppingCart.getGoodInCart().keySet()) {
            System.out.print(good.getName()+"\t");
        }
    }
}
