package views.userMenu;

import models.UsersModels.AccountType;
import views.Menu;

public class SignUpMenu extends Menu {
    public SignUpMenu( Menu parentMenu) {
        super("Sign up", parentMenu);
    }

    @Override
    public void show() {
        System.out.println("Sign up:");
        System.out.println("What type of Account do you want to make?");
        System.out.println("1.Seller");
        System.out.println("2.Customer");
        System.out.println("3.Back");
    }

    @Override
    public void execute() {

        Menu nextMenu=null;
        int input= Integer.parseInt(inputFormat("^\\d+$").trim());
        if(input==1){
            try {
                signUp(AccountType.SELLER);
            } catch (Exception e) {
            }
            nextMenu=parentMenu;
        }else if(input==2){
            try {
                signUp(AccountType.CUSTOMER);
            } catch (Exception e) {
            }
            nextMenu=parentMenu;

        }else if(input==3){

            nextMenu=parentMenu;
        }
        nextMenu.show();
        nextMenu.execute();
    }
    public void signUp(AccountType accountType) throws Exception{
        boolean isPasswordsSame;
        boolean isThisUserNameUsed;
        String companyName=null;
        String userName;
        do{
             userName=inputFormatWithHelpText(".+","User name:");
             try {
                  userController.isThisUsernameUsed(userName);
                  break;
             }catch (Exception e){
                 System.out.println(e.getMessage());
             }
        }while (true);
        String firstName=inputFormatWithHelpText("\\w+","First name:");
        String lastName=inputFormatWithHelpText("\\w+","Last name:");
        String emailAddress=inputFormatWithHelpText("^(\\w+)@\\w+(.\\w+)$","Email address:");
        String telephoneNumber=inputFormatWithHelpText("^\\d{11}$","Telephone Number:");
        String password;
        do {
            password = inputFormatWithHelpText(".+", "password:");
            String repeatedPassword = inputFormatWithHelpText(".+", "please repeat your password:");
            isPasswordsSame= userController.confirmPassword(password,repeatedPassword);
        }while(!isPasswordsSame);
        if(accountType.equals(AccountType.CUSTOMER)) {
            userController.addCustomer(userName, firstName, lastName, emailAddress, telephoneNumber, password);
            System.out.println("Account added to store.");
        }else if(accountType.equals(AccountType.SELLER)){
            companyName=inputFormatWithHelpText(".+","Company name:");
            System.out.println("Your request has been send to manager,Thanks for your request");
        }else if(accountType.equals(AccountType.MANAGER)){
            userController.addManager(userName,firstName,lastName,emailAddress,telephoneNumber,password);
        }
    }
}
