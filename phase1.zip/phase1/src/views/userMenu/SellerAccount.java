package views.userMenu;

import models.UsersModels.Seller;
import views.Menu;

public class SellerAccount extends Menu {
    private Seller seller;
    public SellerAccount(Seller seller, Menu parentMenu) {
        super("You account", parentMenu);
        this.seller = seller;
    }

    @Override
    public void show() {
        showSellersFields();
    }

    @Override
    public void execute() {
        Menu nextMenu = this;
        int input = Integer.parseInt(inputFormatWithHelpText("^1|2|3|4|5$","Enter a number:"));
        if(input == 1){
            CustomerAccount.showAccountInformation(seller);
        }else if(input == 2){
            nextMenu = new ChangeInformation(this,seller);
        }else if(input == 3){
            nextMenu = new RequestMenu(this);
        }else if(input == 4){

        }else if(input == 5){

        }
        else if(input == 6){

        }
        nextMenu.show();
        nextMenu.execute();

    }
    private void showSellersFields(){
        System.out.println("1.Account information");
        System.out.println("2.Change account information");
        System.out.println("3.Send request");
        System.out.println("4.Show and manage goods");
        System.out.println("5.Selling histories");
        System.out.println("6.Company information");
        System.out.println("7.Log out");
        System.out.println("8.Back");

    }
}
