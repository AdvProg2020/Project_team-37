package views.userMenu;

import models.UsersModels.Account;
import models.UsersModels.AccountType;
import models.UsersModels.Seller;
import views.Menu;

public class ChangeInformation extends Menu {
    private Account account2;

    public ChangeInformation(Menu parentMenu, Account account) {
        super("Change information", parentMenu);
        this.account2 = account;
    }

    @Override
    public void show() {
        showAccountInformation(account2);
    }

    @Override
    public void execute() {
        Menu nextMenu=this;
        int input;
        AccountType accountType = account2.getAccountType();
        if (!accountType.equals(AccountType.SELLER)) {
            input = Integer.parseInt(inputFormatWithHelpText("^1|2|3|4|5|6$", "Please Enter a number:"));
            executeForCustomer(input);
            if(input==6){
                nextMenu=parentMenu;
            }
        } else {
            Seller seller=userController.findSellerFromAccount(account2);
            input = Integer.parseInt(inputFormatWithHelpText("^1|2|3|4|5|6|7$", "Please Enter a number:"));
            executeForSeller(input,seller);
            if(input==7)
                nextMenu=parentMenu;
        }
        nextMenu.show();
        nextMenu.execute();
    }

        private void showAccountInformation (Account account){
            AccountType accountType = account.getAccountType();
            Seller seller = userController.findSellerFromAccount(account);
            System.out.println("What do you want to change?");
            System.out.println("1.First name ");
            System.out.println("2.Last name ");
            System.out.println("3.Email address ");
            System.out.println("4.Telephone number ");
            System.out.println("5.Change password");
            if (seller != null) {
                System.out.println("6.Company");
                System.out.println("7.Back");
            } else {
                System.out.println("6.Back");
            }
        }

        private void executeForCustomer (int input) {

            if (input == 1) {
                userController.changeFirstName(account2, inputFormatWithHelpText("\\w+", "First name:"));
                System.out.println("confirmed");
            }
            if (input == 2) {
                userController.changeLastName(account2, inputFormatWithHelpText("\\w+", "Last name:"));
                System.out.println("confirmed");
            }
            if (input == 3) {
                userController.changeEmailAddress(account2, inputFormatWithHelpText("^(.+)@+(.+).(.+)$", "Email address:"));
                System.out.println("confirmed");
            }
            if (input == 4) {
                userController.changeTelephoneNumber(account2, inputFormatWithHelpText("^\\d[11]$+", "Telephone number:"));
                System.out.println("confirmed");
            }
            if (input == 5) {
                userController.changePassword(account2, inputFormatWithHelpText(".+", "Password:"), inputFormatWithHelpText(".+", "Confirm password"));
                System.out.println("confirmed");
            }

        }
        private void executeForSeller(int input,Seller seller){
        executeForCustomer(input);
        if(input==6){
            userController.changeCompanyForSeller(seller,inputFormatWithHelpText(".+","Company:"));
            System.out.println("confirmed");
        }
        }

    }

