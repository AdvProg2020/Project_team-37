package views;

import controller.GoodController;
import controller.SaleController;
import controller.UserController;

import java.util.Scanner;

public class View {
   public static Scanner scanner=new Scanner(System.in);
   public static UserController userController=UserController.getUserController();
   public static GoodController goodController=GoodController.getGoodController();
   public static SaleController saleController = SaleController.getSaleController();
   public static void start(){
      MainMenu mainMenu=new MainMenu();
      mainMenu.show();
      mainMenu.execute();

   }
}
